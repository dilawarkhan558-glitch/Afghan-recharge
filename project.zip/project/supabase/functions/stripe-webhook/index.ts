import { createClient } from "jsr:@supabase/supabase-js@2";
import Stripe from "npm:stripe@14.25.0";

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY")!, {
  apiVersion: "2024-06-20",
});

const DING_API_BASE = Deno.env.get("DING_API_BASE") || "https://api.dingconnect.com/api/v1";

async function getDingApiKey(): Promise<string> {
  const { data } = await supabase.from("app_settings").select("value").eq("key", "DING_API_KEY").maybeSingle();
  return data?.value || Deno.env.get("DING_API_KEY") || "";
}

const OPERATOR_TO_DING_BRAND: Record<string, string> = {
  roshan: "Roshan",
  etisalat: "Etisalat",
  awcc: "Afghan Wireless",
  salaam: "Salaam",
  mtn: "MTN",
};

interface DingProduct {
  BrandName: string;
  ProductId: string;
  SendValue?: number;
  SendCurrencyIso: string;
  ReceiveValue?: number;
  ReceiveCurrencyIso: string;
  MinimumSend?: number;
  MaximumSend?: number;
}

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", ...CORS },
  });
}

function errMsg(e: unknown): string {
  return e instanceof Error ? e.message : String(e);
}

async function dingFetch(apiKey: string, path: string, options?: RequestInit): Promise<unknown> {
  const response = await fetch(`${DING_API_BASE}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`,
      "api_key": apiKey,
      ...options?.headers,
    },
  });

  const data = await response.json();

  if (!response.ok) {
    const errorMsg = (data as Record<string, unknown>).error ||
      (data as Record<string, unknown>).Error ||
      (data as Record<string, unknown>).message ||
      JSON.stringify(data);
    throw new Error(`Ding API ${path} failed (${response.status}): ${errorMsg}`);
  }

  return data;
}

async function getProductsForOperator(apiKey: string, brandName: string): Promise<DingProduct[]> {
  const data = await dingFetch(
    apiKey,
    `/GetProducts?beneficiaryIsoCountryCode=AF&brandName=${encodeURIComponent(brandName)}`,
  ) as Record<string, unknown>;
  const products = (data.Items || data.items || data) as DingProduct[];
  return Array.isArray(products) ? products : [];
}

function findProductForAmount(products: DingProduct[], targetAfn: number): DingProduct | null {
  const exactMatch = products.find(
    (p) => p.ReceiveValue === targetAfn && p.ReceiveCurrencyIso === "AFN",
  );
  if (exactMatch) return exactMatch;

  const flexible = products.find(
    (p) =>
      p.ReceiveCurrencyIso === "AFN" &&
      p.MinimumSend !== undefined &&
      p.MaximumSend !== undefined &&
      targetAfn >= (p.MinimumSend || 0) &&
      targetAfn <= (p.MaximumSend || Infinity),
  );
  if (flexible) return flexible;

  const sorted = products
    .filter((p) => p.ReceiveCurrencyIso === "AFN" && p.ReceiveValue)
    .sort((a, b) =>
      Math.abs((a.ReceiveValue || 0) - targetAfn) -
      Math.abs((b.ReceiveValue || 0) - targetAfn)
    );
  return sorted[0] || null;
}

async function sendTransfer(
  apiKey: string,
  product: DingProduct,
  phoneNumber: string,
  amountAfn: number,
): Promise<{ transactionId: string; sendValue: number; receiveValue: number }> {
  const accountNumber = phoneNumber.replace("+93", "");

  const body: Record<string, unknown> = {
    AccountNumber: accountNumber,
    ProductId: product.ProductId,
    SendValue: amountAfn,
    SendCurrencyIso: "AFN",
  };

  const data = await dingFetch(apiKey, "/SendTransfer", {
    method: "POST",
    body: JSON.stringify(body),
  }) as Record<string, unknown>;

  return {
    transactionId: String(
      data.TransferRef || data.transferRef || data.transactionId || data.id || Date.now(),
    ),
    sendValue: Number(data.SendValue || amountAfn),
    receiveValue: Number(data.ReceiveValue || product.ReceiveValue || amountAfn),
  };
}

async function deliverTopup(
  apiKey: string,
  phoneNumber: string,
  operatorId: string,
  amountAfn: number,
): Promise<{ success: boolean; transaction_id?: string; error?: string }> {
  try {
    if (!apiKey) {
      return { success: false, error: "Ding API key not configured — add it in the Admin Settings panel" };
    }

    const brandName = OPERATOR_TO_DING_BRAND[operatorId];
    if (!brandName) {
      return { success: false, error: `No Ding brand mapping for operator: ${operatorId}` };
    }

    const products = await getProductsForOperator(apiKey, brandName);
    if (!products.length) {
      return { success: false, error: `No Ding products found for ${brandName} in Afghanistan` };
    }

    const product = findProductForAmount(products, amountAfn);
    if (!product) {
      return { success: false, error: `No suitable Ding product found for ${amountAfn} AFN on ${brandName}` };
    }

    const result = await sendTransfer(apiKey, product, phoneNumber, amountAfn);
    return { success: true, transaction_id: result.transactionId };
  } catch (err) {
    return { success: false, error: errMsg(err) };
  }
}

async function autoRefund(rechargeId: string, paymentIntentId: string): Promise<void> {
  try {
    await supabase
      .from("recharges")
      .update({ refund_status: "pending" })
      .eq("id", rechargeId);

    const refund = await stripe.refunds.create({
      payment_intent: paymentIntentId,
    });

    await supabase
      .from("recharges")
      .update({
        refund_status: "succeeded",
        stripe_refund_id: refund.id,
        refund_amount_eur: parseFloat((refund.amount / 100).toFixed(2)),
      })
      .eq("id", rechargeId);
  } catch (err) {
    await supabase
      .from("recharges")
      .update({
        refund_status: "failed",
        refund_error: errMsg(err),
      })
      .eq("id", rechargeId);
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return json({ ok: true });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  try {
    const rawBody = await req.text();
    let event: Stripe.Event;

    const sig = req.headers.get("stripe-signature");
    const webhookSecret = Deno.env.get("STRIPE_WEBHOOK_SECRET");

    if (webhookSecret && sig) {
      try {
        event = await stripe.webhooks.constructEventAsync(rawBody, sig, webhookSecret);
      } catch (err) {
        return json({ error: `Webhook signature verification failed: ${errMsg(err)}` }, 400);
      }
    } else {
      event = JSON.parse(rawBody) as Stripe.Event;
    }

    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;
        const rechargeId = session.metadata?.recharge_id;
        const operatorId = session.metadata?.operator_id;
        const phoneNumber = session.metadata?.phone_number;
        const amountAfn = parseInt(session.metadata?.amount_afn || "0", 10);

        if (!rechargeId || !operatorId || !phoneNumber || !amountAfn) {
          return json({ error: "Missing recharge metadata in session" }, 400);
        }

        const paymentIntentId = session.payment_intent as string;

        // Mark payment as paid
        await supabase
          .from("recharges")
          .update({
            payment_status: "paid",
            stripe_payment_intent_id: paymentIntentId || null,
            topup_status: "processing",
          })
          .eq("id", rechargeId);

        // Auto-deliver the top-up via DingConnect
        const dingApiKey = await getDingApiKey();
        const result = await deliverTopup(dingApiKey, phoneNumber, operatorId, amountAfn);

        if (result.success) {
          await supabase
            .from("recharges")
            .update({
              status: "completed",
              topup_status: "success",
              topup_transaction_id: result.transaction_id || null,
            })
            .eq("id", rechargeId);
        } else {
          // Top-up failed — auto-refund the customer via Stripe
          await supabase
            .from("recharges")
            .update({
              status: "failed",
              topup_status: "failed",
              topup_error: result.error || "Unknown error",
            })
            .eq("id", rechargeId);

          if (paymentIntentId) {
            await autoRefund(rechargeId, paymentIntentId);
          }
        }

        return json({ received: true, topup_success: result.success });
      }

      case "checkout.session.expired": {
        const session = event.data.object as Stripe.Checkout.Session;
        const rechargeId = session.metadata?.recharge_id;
        if (rechargeId) {
          await supabase
            .from("recharges")
            .update({
              payment_status: "failed",
              status: "failed",
              topup_status: "skipped",
              topup_error: "Checkout session expired",
            })
            .eq("id", rechargeId);
        }
        return json({ received: true });
      }

      default:
        return json({ received: true, type: event.type });
    }
  } catch (err) {
    return json({ error: errMsg(err) }, 500);
  }
});
