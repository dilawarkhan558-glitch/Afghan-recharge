import { createClient } from "jsr:@supabase/supabase-js@2";
import Stripe from "npm:stripe@14.25.0";

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY")!, {
  apiVersion: "2024-06-20",
});

const DING_API_BASE = Deno.env.get("DING_API_BASE") || "https://api.dingconnect.com/api/v1";

async function getDingApiKey(): Promise<string> {
  const { data } = await supabase.from("app_settings").select("value").eq("key", "DING_API_KEY").maybeSingle();
  return data?.value || Deno.env.get("DING_API_KEY") || "";
}

// Pricing constants — must match src/lib/pricing.ts
const PROFIT_MARGIN = 0.10;

// Fallback base costs per AFN denomination (used when DingConnect lookup fails)
const FALLBACK_BASE_COST_EUR: Record<number, number> = {
  100: 1.80,
  200: 3.60,
  500: 9.00,
  1000: 18.00,
};

const OPERATOR_TO_DING_BRAND: Record<string, string> = {
  roshan: "Roshan",
  etisalat: "Etisalat",
  awcc: "Afghan Wireless",
  salaam: "Salaam",
  mtn: "MTN",
};

interface DingProduct {
  BrandName: string;
  ProductId: string;
  SendValue?: number;
  SendCurrencyIso: string;
  ReceiveValue?: number;
  ReceiveCurrencyIso: string;
  MinimumSend?: number;
  MaximumSend?: number;
}

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", ...CORS },
  });
}

function errMsg(e: unknown): string {
  return e instanceof Error ? e.message : String(e);
}

function calculateSellingPrice(baseCostEur: number): number {
  return Number((baseCostEur * (1 + PROFIT_MARGIN)).toFixed(2));
}

function getFallbackBaseCost(afnAmount: number): number {
  return FALLBACK_BASE_COST_EUR[afnAmount] ?? (afnAmount / 100) * 1.8;
}

async function dingFetch(apiKey: string, path: string, options?: RequestInit): Promise<unknown> {
  const response = await fetch(`${DING_API_BASE}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`,
      "api_key": apiKey,
      ...options?.headers,
    },
  });

  const data = await response.json();

  if (!response.ok) {
    const errorMsg = (data as Record<string, unknown>).error ||
      (data as Record<string, unknown>).Error ||
      (data as Record<string, unknown>).message ||
      JSON.stringify(data);
    throw new Error(`Ding API ${path} failed (${response.status}): ${errorMsg}`);
  }

  return data;
}

async function getDingBaseCost(apiKey: string, operatorId: string, afnAmount: number): Promise<number> {
  const brandName = OPERATOR_TO_DING_BRAND[operatorId];
  if (!brandName) return getFallbackBaseCost(afnAmount);

  try {
    const data = await dingFetch(
      apiKey,
      `/GetProducts?beneficiaryIsoCountryCode=AF&brandName=${encodeURIComponent(brandName)}`,
    ) as Record<string, unknown>;
    const products = (data.Items || data.items || data) as DingProduct[];
    if (!Array.isArray(products)) return getFallbackBaseCost(afnAmount);

    // Find a product matching the requested AFN amount
    const exactMatch = products.find(
      (p) => p.ReceiveValue === afnAmount && p.ReceiveCurrencyIso === "AFN",
    );
    if (exactMatch && exactMatch.SendValue && exactMatch.SendCurrencyIso === "EUR") {
      return exactMatch.SendValue;
    }

    // Try flexible-range product
    const flexible = products.find(
      (p) =>
        p.ReceiveCurrencyIso === "AFN" &&
        p.MinimumSend !== undefined &&
        p.MaximumSend !== undefined &&
        afnAmount >= (p.MinimumSend || 0) &&
        afnAmount <= (p.MaximumSend || Infinity),
    );
    if (flexible && flexible.SendValue && flexible.SendCurrencyIso === "EUR") {
      return flexible.SendValue;
    }

    // Nearest product by receive value
    const sorted = products
      .filter((p) => p.ReceiveCurrencyIso === "AFN" && p.SendValue)
      .sort((a, b) =>
        Math.abs((a.ReceiveValue || 0) - afnAmount) -
        Math.abs((b.ReceiveValue || 0) - afnAmount)
      );
    if (sorted[0] && sorted[0].SendValue && sorted[0].SendCurrencyIso === "EUR") {
      return sorted[0].SendValue;
    }
  } catch (err) {
    console.error(`DingConnect product lookup failed, using fallback: ${errMsg(err)}`);
  }

  return getFallbackBaseCost(afnAmount);
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return json({ ok: true });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  try {
    const body = await req.json();
    const { operator_id, phone_number, amount_afn, service_fee_afn } = body;

    if (!operator_id || !phone_number || !amount_afn) {
      return json({ error: "Missing required fields" }, 400);
    }

    const afnAmount = parseInt(String(amount_afn), 10);
    if (!afnAmount || afnAmount < 10) {
      return json({ error: "Invalid amount_afn" }, 400);
    }

    // 1. Determine base cost from DingConnect (with fallback)
    const dingApiKey = await getDingApiKey();
    const baseCostEur = await getDingBaseCost(dingApiKey, operator_id, afnAmount);

    // 2. Calculate the authoritative selling price
    const sellingPriceEur = calculateSellingPrice(baseCostEur);

    // 3. Create the recharge record
    const { data: recharge, error: dbError } = await supabase
      .from("recharges")
      .insert({
        operator_id,
        phone_number,
        amount_afn: afnAmount,
        service_fee_afn: service_fee_afn || 0,
        amount_eur: parseFloat(sellingPriceEur.toFixed(2)),
        base_cost_eur: parseFloat(baseCostEur.toFixed(2)),
        status: "pending",
        payment_status: "pending",
        topup_status: "pending",
      })
      .select()
      .single();

    if (dbError) throw dbError;

    // 4. Create Stripe Checkout Session
    const origin = req.headers.get("origin") || "https://blbhwfismgacoxemnkym.supabase.co";
    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items: [
        {
          price_data: {
            currency: "eur",
            product_data: {
              name: `Mobile Recharge — ${afnAmount} AFN`,
              description: `Top-up for ${phone_number} (${operator_id})`,
            },
            unit_amount: Math.round(sellingPriceEur * 100),
          },
          quantity: 1,
        },
      ],
      metadata: {
        recharge_id: recharge.id,
        operator_id,
        phone_number,
        amount_afn: String(afnAmount),
        service_fee_afn: String(service_fee_afn || 0),
        base_cost_eur: baseCostEur.toFixed(2),
        selling_price_eur: sellingPriceEur.toFixed(2),
      },
      success_url: `${origin}/?recharge_id=${recharge.id}&status=success`,
      cancel_url: `${origin}/?recharge_id=${recharge.id}&status=cancelled`,
    });

    // 5. Store the Stripe session ID
    await supabase
      .from("recharges")
      .update({ stripe_checkout_session_id: session.id })
      .eq("id", recharge.id);

    return json({
      checkout_url: session.url,
      recharge_id: recharge.id,
      session_id: session.id,
      selling_price_eur: parseFloat(sellingPriceEur.toFixed(2)),
      base_cost_eur: parseFloat(baseCostEur.toFixed(2)),
    });
  } catch (err) {
    return json({ error: errMsg(err) }, 500);
  }
});
