import { createClient } from "jsr:@supabase/supabase-js@2";

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

const DING_API_BASE = Deno.env.get("DING_API_BASE") || "https://api.dingconnect.com/api/v1";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", ...CORS },
  });
}

function errMsg(e: unknown): string {
  return e instanceof Error ? e.message : String(e);
}

async function getSetting(key: string): Promise<string | null> {
  const { data } = await supabase
    .from("app_settings")
    .select("value")
    .eq("key", key)
    .maybeSingle();
  return data?.value ?? null;
}

async function getDingApiKey(): Promise<string> {
  const fromDb = await getSetting("DING_API_KEY");
  return fromDb || Deno.env.get("DING_API_KEY") || "";
}

async function dingFetch(apiKey: string, path: string, options?: RequestInit): Promise<unknown> {
  const response = await fetch(`${DING_API_BASE}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`,
      "api_key": apiKey,
      ...options?.headers,
    },
  });

  const data = await response.json();

  if (!response.ok) {
    const errorMsg = (data as Record<string, unknown>).error ||
      (data as Record<string, unknown>).Error ||
      (data as Record<string, unknown>).message ||
      JSON.stringify(data);
    throw new Error(`Ding API ${path} failed (${response.status}): ${errorMsg}`);
  }

  return data;
}

/*
 * Admin API endpoint.
 *
 * Actions (query param or body):
 * - "balance"       → fetches current DingConnect balance
 * - "stats"         → aggregated transaction stats
 * - "recent"        → recent transactions list
 * - "get_settings"  → returns which keys are configured (never the values)
 * - "save_settings" → saves API keys to the locked-down app_settings table
 */

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return json({ ok: true });

  try {
    let action: string;
    let body: Record<string, unknown> = {};

    if (req.method === "POST") {
      body = await req.json();
      action = (body.action as string) || "balance";
    } else {
      const url = new URL(req.url);
      action = url.searchParams.get("action") || "balance";
    }

    // --- get_settings: returns which keys are configured (boolean flags only) ---
    if (action === "get_settings") {
      const dingApiKey = await getSetting("DING_API_KEY");
      const dingWebhookSecret = await getSetting("DING_WEBHOOK_SECRET");
      const dingApiKeyEnv = Deno.env.get("DING_API_KEY") || "";

      return json({
        DING_API_KEY: {
          configured: !!(dingApiKey || dingApiKeyEnv),
          source: dingApiKey ? "database" : dingApiKeyEnv ? "environment" : "none",
        },
        DING_WEBHOOK_SECRET: {
          configured: !!dingWebhookSecret,
          source: dingWebhookSecret ? "database" : "none",
        },
      });
    }

    // --- save_settings: persists keys to app_settings (server-side only) ---
    if (action === "save_settings") {
      const settings = body.settings as Record<string, string>;

      if (!settings || typeof settings !== "object") {
        return json({ error: "settings object required" }, 400);
      }

      const allowedKeys = ["DING_API_KEY", "DING_WEBHOOK_SECRET"];
      const saved: string[] = [];
      const errors: string[] = [];

      for (const [key, value] of Object.entries(settings)) {
        if (!allowedKeys.includes(key)) continue;
        if (typeof value !== "string" || value.trim().length < 4) {
          errors.push(`${key}: value too short`);
          continue;
        }

        const { error } = await supabase
          .from("app_settings")
          .upsert({ key, value: value.trim(), updated_at: new Date().toISOString() });

        if (error) {
          errors.push(`${key}: ${error.message}`);
        } else {
          saved.push(key);
        }
      }

      return json({ saved, errors, ok: errors.length === 0 });
    }

    // --- balance ---
    if (action === "balance") {
      const apiKey = await getDingApiKey();
      if (!apiKey) {
        return json({ balance: null, error: "DING_API_KEY not configured — please add it in Settings" });
      }

      try {
        const data = await dingFetch(apiKey, "/GetBalance") as Record<string, unknown>;
        const balance = data.Balance ?? data.balance ?? 0;
        const currency = data.CurrencyIso ?? data.currency ?? "EUR";

        return json({
          balance: Number(balance),
          currency: String(currency),
          raw: data,
        });
      } catch (err) {
        return json({
          balance: null,
          error: `Could not fetch Ding balance: ${errMsg(err)}`,
        });
      }
    }

    // --- stats ---
    if (action === "stats") {
      const { data: allRecharges, error } = await supabase
        .from("recharges")
        .select("status, topup_status, payment_status, refund_status, amount_eur, base_cost_eur, refund_amount_eur, created_at")
        .order("created_at", { ascending: false });

      if (error) return json({ error: error.message }, 500);

      const total = allRecharges?.length || 0;
      const completed = allRecharges?.filter((r) => r.status === "completed").length || 0;
      const failed = allRecharges?.filter((r) => r.status === "failed").length || 0;
      const pending = allRecharges?.filter((r) => r.status === "pending").length || 0;
      const refunded = allRecharges?.filter((r) => r.refund_status === "succeeded").length || 0;

      const totalRevenue = allRecharges
        ?.filter((r) => r.status === "completed")
        .reduce((sum, r) => sum + Number(r.amount_eur || 0), 0) || 0;

      const totalCost = allRecharges
        ?.filter((r) => r.status === "completed")
        .reduce((sum, r) => sum + Number(r.base_cost_eur || 0), 0) || 0;

      const totalRefunded = allRecharges
        ?.filter((r) => r.refund_status === "succeeded")
        .reduce((sum, r) => sum + Number(r.refund_amount_eur || 0), 0) || 0;

      return json({
        total,
        completed,
        failed,
        pending,
        refunded,
        total_revenue_eur: parseFloat(totalRevenue.toFixed(2)),
        total_cost_eur: parseFloat(totalCost.toFixed(2)),
        total_refunded_eur: parseFloat(totalRefunded.toFixed(2)),
        net_profit_eur: parseFloat((totalRevenue - totalCost).toFixed(2)),
      });
    }

    // --- recent ---
    if (action === "recent") {
      const limit = parseInt(String(body.limit || 20), 10);
      const { data: recent, error } = await supabase
        .from("recharges")
        .select("id, operator_id, phone_number, amount_afn, amount_eur, base_cost_eur, status, topup_status, payment_status, refund_status, topup_transaction_id, topup_error, created_at")
        .order("created_at", { ascending: false })
        .limit(limit);

      if (error) return json({ error: error.message }, 500);

      return json({ transactions: recent || [] });
    }

    return json({ error: "Unknown action" }, 400);
  } catch (err) {
    return json({ error: errMsg(err) }, 500);
  }
});
