import { createClient } from "jsr:@supabase/supabase-js@2";

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

const DING_API_KEY = Deno.env.get("DING_API_KEY") || "HCX6f8sCmml5cKOi7iRCKH";
const DING_API_BASE = Deno.env.get("DING_API_BASE") || "https://api.dingconnect.com/api/v1";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", ...CORS },
  });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return json({ ok: true });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  try {
    const body = await req.json();

    // Action: check — called by frontend to poll payment + top-up status
    if (body.action === "check") {
      const { recharge_id } = body;
      if (!recharge_id) return json({ error: "Missing recharge_id" }, 400);

      const { data, error } = await supabase
        .from("recharges")
        .select("status, payment_status, topup_status, topup_error, topup_transaction_id, operator_id, phone_number, amount_afn")
        .eq("id", recharge_id)
        .single();

      if (error) return json({ error: error.message }, 500);

      return json({
        status: data.status,
        payment_status: data.payment_status,
        topup_status: data.topup_status,
        topup_error: data.topup_error,
        transaction_id: data.topup_transaction_id,
        operator_id: data.operator_id,
        phone_number: data.phone_number,
        amount_afn: data.amount_afn,
        completed: data.status === "completed" && data.topup_status === "success",
        failed: data.status === "failed" || data.topup_status === "failed",
        processing: data.topup_status === "processing" || data.payment_status === "pending",
      });
    }

    return json({ error: "Unknown action" }, 400);
  } catch (err) {
    return json({
      error: err instanceof Error ? err.message : String(err),
    }, 500);
  }
});
