import { createClient, type SupabaseClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

let client: SupabaseClient;

try {
  client = createClient(
    supabaseUrl || 'https://placeholder.supabase.co',
    supabaseAnonKey || 'placeholder-anon-key',
  );
} catch (e) {
  console.error('Failed to initialize Supabase client:', e);
  client = createClient('https://placeholder.supabase.co', 'placeholder-anon-key');
}

export const supabase = client;
