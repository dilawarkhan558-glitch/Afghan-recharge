import { useState, useEffect, useCallback } from 'react';
import {
  Settings as SettingsIcon,
  Globe,
  Check,
  KeyRound,
  Eye,
  EyeOff,
  Save,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  Bell,
  Smartphone,
  Info,
  Lock,
  CreditCard,
} from 'lucide-react';
import { useI18n, LANGUAGES } from '@/lib/i18n';
import type { Language } from '@/lib/i18n/types';
import { supabase } from '@/lib/supabase';

const WHATSAPP_URL =
  'https://wa.me/393512121290?text=' + encodeURIComponent('Salam, Afghan Topup help');
const EMAIL_URL = 'mailto:afghantopup.support@gmail.com';

interface KeyStatus {
  configured: boolean;
  source: 'database' | 'environment' | 'none';
}

export function SettingsView() {
  const { lang, t, setLang } = useI18n();

  const [dingKey, setDingKey] = useState('');
  const [showDingKey, setShowDingKey] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saveResult, setSaveResult] = useState<{ ok: boolean; msg: string } | null>(null);
  const [keyStatus, setKeyStatus] = useState<KeyStatus | null>(null);
  const [checkingKeys, setCheckingKeys] = useState(true);

  const loadStatus = useCallback(async () => {
    try {
      const { data } = await supabase.functions.invoke('admin', {
        body: { action: 'get_settings' },
      });
      if (data) {
        const status = data as { DING_API_KEY: KeyStatus };
        setKeyStatus(status.DING_API_KEY);
      }
    } catch {
      // ignore
    }
    setCheckingKeys(false);
  }, []);

  useEffect(() => {
    loadStatus();
  }, [loadStatus]);

  async function handleSaveKey(e: React.FormEvent) {
    e.preventDefault();
    if (!dingKey.trim() || dingKey.trim().length < 4) {
      setSaveResult({ ok: false, msg: 'Please enter a valid API key.' });
      return;
    }
    setSaving(true);
    setSaveResult(null);
    try {
      const { data, error } = await supabase.functions.invoke('admin', {
        body: { action: 'save_settings', settings: { DING_API_KEY: dingKey.trim() } },
      });
      if (error) throw error;
      const res = data as { ok: boolean; saved: string[]; errors: string[] };
      if (res.ok) {
        setSaveResult({ ok: true, msg: 'API key saved securely.' });
        setDingKey('');
        setShowDingKey(false);
        await loadStatus();
      } else {
        setSaveResult({ ok: false, msg: res.errors?.join(', ') || 'Save failed.' });
      }
    } catch (err) {
      setSaveResult({ ok: false, msg: err instanceof Error ? err.message : 'Save failed.' });
    } finally {
      setSaving(false);
    }
  }

  return (
    <section className="mt-6">
      <div className="flex items-center gap-2 mb-1">
        <SettingsIcon className="w-5 h-5 text-afghan-red" />
        <h2 className="text-lg font-bold text-gray-900">Settings</h2>
      </div>
      <p className="text-sm text-gray-500 mb-5">Manage your app preferences and API keys</p>

      {/* Language */}
      <div className="mb-4 p-4 rounded-2xl bg-white border border-gray-100 shadow-sm">
        <div className="flex items-center gap-2 mb-3">
          <Globe className="w-4 h-4 text-gray-500" />
          <h3 className="text-sm font-bold text-gray-900">Language</h3>
        </div>
        <div className="space-y-2">
          {LANGUAGES.map((l) => (
            <button
              key={l.code}
              onClick={() => setLang(l.code as Language)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-sm transition-colors ${
                lang === l.code
                  ? 'bg-afghan-green-light text-afghan-green-dark font-semibold'
                  : 'text-gray-700 hover:bg-gray-50'
              }`}
            >
              <span className="flex items-center gap-2.5">
                <span className="text-xs font-bold text-gray-400 w-6">{l.flag}</span>
                {l.nativeLabel}
              </span>
              {lang === l.code && <Check className="w-4 h-4 text-afghan-green" />}
            </button>
          ))}
        </div>
      </div>

      {/* API Key Management */}
      <div className="mb-4 p-4 rounded-2xl bg-white border border-gray-100 shadow-sm">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <KeyRound className="w-4 h-4 text-gray-500" />
            <h3 className="text-sm font-bold text-gray-900">DingConnect API Key</h3>
          </div>
          {!checkingKeys && keyStatus && (
            keyStatus.configured ? (
              <span className="flex items-center gap-1 text-xs font-semibold text-afghan-green">
                <ShieldCheck className="w-3.5 h-3.5" />
                Configured
              </span>
            ) : (
              <span className="flex items-center gap-1 text-xs font-semibold text-amber-600">
                <AlertCircle className="w-3.5 h-3.5" />
                Not set
              </span>
            )
          )}
        </div>

        <form onSubmit={handleSaveKey} className="space-y-3">
          <div className="relative">
            <input
              type={showDingKey ? 'text' : 'password'}
              value={dingKey}
              onChange={(e) => setDingKey(e.target.value)}
              placeholder={
                keyStatus?.configured
                  ? '••••••• (enter new key to replace)'
                  : 'Paste your DingConnect API key'
              }
              className="w-full px-4 py-3 pr-11 rounded-xl border border-gray-200 bg-gray-50 text-sm font-mono text-gray-900 outline-none focus:border-afghan-red focus:ring-2 focus:ring-afghan-red/10 transition-colors"
              autoComplete="off"
              spellCheck={false}
            />
            <button
              type="button"
              onClick={() => setShowDingKey((v) => !v)}
              className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
              tabIndex={-1}
            >
              {showDingKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>

          {saveResult && (
            <div
              className={`flex items-center gap-2 p-2.5 rounded-lg text-xs font-medium ${
                saveResult.ok
                  ? 'bg-afghan-green-light border border-afghan-green/20 text-afghan-green-dark'
                  : 'bg-afghan-red-light border border-afghan-red/20 text-afghan-red'
              }`}
            >
              {saveResult.ok ? (
                <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
              ) : (
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
              )}
              {saveResult.msg}
            </div>
          )}

          <button
            type="submit"
            disabled={saving}
            className="w-full py-3 rounded-xl bg-afghan-red text-white text-sm font-bold flex items-center justify-center gap-2 hover:bg-afghan-red-dark transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {saving ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <Save className="w-4 h-4" />
            )}
            {saving ? 'Saving...' : 'Save Key Securely'}
          </button>
        </form>

        <p className="text-xs text-gray-400 mt-3">
          Stored server-side — never visible to customers.
        </p>
      </div>

      {/* App Info */}
      <div className="mb-4 p-4 rounded-2xl bg-white border border-gray-100 shadow-sm">
        <div className="flex items-center gap-2 mb-3">
          <Info className="w-4 h-4 text-gray-500" />
          <h3 className="text-sm font-bold text-gray-900">About</h3>
        </div>
        <div className="space-y-2.5 text-sm">
          <div className="flex items-center justify-between">
            <span className="text-gray-500">Version</span>
            <span className="font-medium text-gray-900">1.0.0</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-gray-500">Platform</span>
            <span className="font-medium text-gray-900">Web · PWA</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-gray-500">Payment</span>
            <span className="font-medium text-gray-900 flex items-center gap-1">
              <CreditCard className="w-3.5 h-3.5 text-afghan-red" />
              Stripe
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-gray-500">Top-up Provider</span>
            <span className="font-medium text-gray-900">DingConnect</span>
          </div>
        </div>
      </div>

      {/* Support */}
      <div className="mb-4 p-4 rounded-2xl bg-white border border-gray-100 shadow-sm">
        <div className="flex items-center gap-2 mb-3">
          <Bell className="w-4 h-4 text-gray-500" />
          <h3 className="text-sm font-bold text-gray-900">Support</h3>
        </div>
        <a
          href={WHATSAPP_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-3 p-3 rounded-xl bg-gradient-to-r from-afghan-green to-afghan-green-dark text-white text-sm font-bold hover:shadow-lg transition-all mb-2"
        >
          <Smartphone className="w-4 h-4" />
          WhatsApp: +39 351 212 1290
        </a>
        <a
          href={EMAIL_URL}
          className="flex items-center gap-3 p-3 rounded-xl border border-gray-200 text-gray-700 text-sm font-bold hover:bg-gray-50 transition-all"
        >
          <Info className="w-4 h-4 text-afghan-red" />
          afghantopup.support@gmail.com
        </a>
      </div>

      {/* Privacy */}
      <div className="p-4 rounded-2xl bg-gray-50 border border-gray-100">
        <div className="flex items-start gap-2.5">
          <Lock className="w-4 h-4 text-gray-400 mt-0.5 shrink-0" />
          <p className="text-xs text-gray-500 leading-relaxed">
            Your data is protected with 256-bit SSL encryption. Payment is processed by Stripe.
            Top-ups delivered via DingConnect. We never store your card details.
          </p>
        </div>
      </div>

      <p className="text-center text-xs text-gray-400 mt-6 mb-2">{t.poweredBy}</p>
    </section>
  );
}
