import { useState, useEffect, useCallback } from 'react';
import {
  Wallet, TrendingUp, RefreshCw, CheckCircle2, XCircle, Clock,
  ArrowLeft, BarChart3, AlertCircle, Settings, Eye, EyeOff,
  KeyRound, ShieldCheck, Save, Lock,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { getOperator } from '@/lib/operators';
import { OperatorLogo } from './OperatorLogos';

// Simple PIN stored in localStorage — not secret-grade security, just to keep
// casual visitors out of the admin panel. A proper admin login would require auth.
const ADMIN_PIN = '1234'; // Change this to your preferred PIN
const PIN_STORAGE_KEY = 'admin_unlocked';

interface AdminStats {
  total: number;
  completed: number;
  failed: number;
  pending: number;
  refunded: number;
  total_revenue_eur: number;
  total_cost_eur: number;
  total_refunded_eur: number;
  net_profit_eur: number;
}

interface DingBalance {
  balance: number | null;
  currency: string;
  error?: string;
}

interface Transaction {
  id: string;
  operator_id: string;
  phone_number: string;
  amount_afn: number;
  amount_eur: number;
  base_cost_eur: number;
  status: string;
  topup_status: string;
  payment_status: string;
  refund_status: string;
  topup_transaction_id: string | null;
  topup_error: string | null;
  created_at: string;
}

interface KeyStatus {
  configured: boolean;
  source: 'database' | 'environment' | 'none';
}

interface SettingsStatus {
  DING_API_KEY: KeyStatus;
  DING_WEBHOOK_SECRET: KeyStatus;
}

function formatEur(value: number): string {
  return new Intl.NumberFormat('en-DE', {
    style: 'currency',
    currency: 'EUR',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value);
}

function formatTime(iso: string): string {
  return new Date(iso).toLocaleString('en-GB', {
    day: '2-digit',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function StatusBadge({ status }: { status: string }) {
  const config: Record<string, { bg: string; text: string; label: string }> = {
    completed: { bg: 'bg-green-100', text: 'text-green-700', label: 'SUCCESS' },
    failed: { bg: 'bg-red-100', text: 'text-red-700', label: 'FAILED' },
    pending: { bg: 'bg-amber-100', text: 'text-amber-700', label: 'PENDING' },
  };
  const c = config[status] || { bg: 'bg-gray-100', text: 'text-gray-600', label: status.toUpperCase() };
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold ${c.bg} ${c.text}`}>
      {c.label}
    </span>
  );
}

function StatCard({ icon, label, value, bg }: { icon: React.ReactNode; label: string; value: number; bg: string }) {
  return (
    <div className={`p-4 rounded-2xl ${bg} border border-gray-100`}>
      <div className="flex items-center gap-1.5 mb-1">
        {icon}
        <p className="text-xs font-medium text-gray-600">{label}</p>
      </div>
      <p className="text-2xl font-bold text-gray-900">{value}</p>
    </div>
  );
}

// ─── PIN Gate ──────────────────────────────────────────────────────────────

function PinGate({ onUnlock }: { onUnlock: () => void }) {
  const [pin, setPin] = useState('');
  const [wrong, setWrong] = useState(false);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (pin === ADMIN_PIN) {
      try { sessionStorage.setItem(PIN_STORAGE_KEY, '1'); } catch { /* ignore */ }
      onUnlock();
    } else {
      setWrong(true);
      setPin('');
      setTimeout(() => setWrong(false), 2000);
    }
  }

  return (
    <div className="flex flex-col items-center justify-center py-20 px-6">
      <div className="w-16 h-16 rounded-2xl bg-blue-50 flex items-center justify-center mb-5">
        <Lock className="w-8 h-8 text-blue-600" />
      </div>
      <h2 className="text-xl font-bold text-gray-900 mb-1">Admin Access</h2>
      <p className="text-sm text-gray-500 mb-8 text-center">Enter your admin PIN to continue</p>
      <form onSubmit={handleSubmit} className="w-full max-w-xs space-y-4">
        <input
          type="password"
          inputMode="numeric"
          placeholder="Enter PIN"
          value={pin}
          onChange={(e) => setPin(e.target.value)}
          maxLength={8}
          className={`w-full px-4 py-3.5 rounded-xl border text-center text-lg font-bold tracking-widest transition-colors outline-none focus:ring-2 focus:ring-blue-400 ${
            wrong ? 'border-red-400 bg-red-50 text-red-700' : 'border-gray-200 bg-white text-gray-900'
          }`}
          autoFocus
        />
        {wrong && <p className="text-sm text-red-600 text-center font-medium">Incorrect PIN</p>}
        <button
          type="submit"
          className="w-full py-3.5 rounded-xl bg-blue-600 text-white font-bold hover:bg-blue-700 transition-colors"
        >
          Unlock
        </button>
      </form>
    </div>
  );
}

// ─── Settings Panel ─────────────────────────────────────────────────────────

function SettingsPanel() {
  const [dingKey, setDingKey] = useState('');
  const [webhookSecret, setWebhookSecret] = useState('');
  const [showDingKey, setShowDingKey] = useState(false);
  const [showWebhook, setShowWebhook] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saveResult, setSaveResult] = useState<{ ok: boolean; msg: string } | null>(null);
  const [keyStatus, setKeyStatus] = useState<SettingsStatus | null>(null);
  const [loadingStatus, setLoadingStatus] = useState(true);

  const loadStatus = useCallback(async () => {
    try {
      const { data } = await supabase.functions.invoke('admin', { body: { action: 'get_settings' } });
      if (data) setKeyStatus(data as SettingsStatus);
    } catch {
      // ignore
    } finally {
      setLoadingStatus(false);
    }
  }, []);

  useEffect(() => { loadStatus(); }, [loadStatus]);

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    if (!dingKey.trim() && !webhookSecret.trim()) {
      setSaveResult({ ok: false, msg: 'Enter at least one key to save.' });
      return;
    }
    setSaving(true);
    setSaveResult(null);
    try {
      const settings: Record<string, string> = {};
      if (dingKey.trim()) settings['DING_API_KEY'] = dingKey.trim();
      if (webhookSecret.trim()) settings['DING_WEBHOOK_SECRET'] = webhookSecret.trim();

      const { data, error } = await supabase.functions.invoke('admin', {
        body: { action: 'save_settings', settings },
      });

      if (error) throw error;

      const result = data as { ok: boolean; saved: string[]; errors: string[] };
      if (result.ok) {
        setSaveResult({ ok: true, msg: `Saved: ${result.saved.join(', ')}` });
        setDingKey('');
        setWebhookSecret('');
        await loadStatus();
      } else {
        setSaveResult({ ok: false, msg: result.errors.join(', ') || 'Save failed.' });
      }
    } catch (err) {
      setSaveResult({ ok: false, msg: err instanceof Error ? err.message : 'Save failed.' });
    } finally {
      setSaving(false);
    }
  }

  function KeyStatusIndicator({ name, status }: { name: string; status?: KeyStatus }) {
    if (loadingStatus) return <span className="text-xs text-gray-400">Checking...</span>;
    if (!status) return null;
    if (status.configured) {
      return (
        <span className="flex items-center gap-1 text-xs font-semibold text-green-600">
          <ShieldCheck className="w-3.5 h-3.5" />
          {status.source === 'database' ? 'Saved in database' : 'Set via environment'}
        </span>
      );
    }
    return (
      <span className="flex items-center gap-1 text-xs font-semibold text-amber-600">
        <AlertCircle className="w-3.5 h-3.5" />
        Not configured
      </span>
    );
  }

  return (
    <div className="space-y-5">
      {/* How it works */}
      <div className="p-4 rounded-2xl bg-blue-50 border border-blue-100">
        <div className="flex items-start gap-2.5">
          <ShieldCheck className="w-4 h-4 text-blue-600 mt-0.5 shrink-0" />
          <div className="text-xs text-blue-800 space-y-1">
            <p className="font-semibold">Stored securely server-side</p>
            <p>Keys are saved in a locked database table. They are never sent to or visible in your browser — only your backend functions can read them.</p>
          </div>
        </div>
      </div>

      <form onSubmit={handleSave} className="space-y-4">
        {/* DING_API_KEY */}
        <div className="p-4 rounded-2xl bg-white border border-gray-100 shadow-sm space-y-2.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <KeyRound className="w-4 h-4 text-gray-500" />
              <label className="text-sm font-semibold text-gray-900">DingConnect API Key</label>
            </div>
            <KeyStatusIndicator name="DING_API_KEY" status={keyStatus?.DING_API_KEY} />
          </div>
          <div className="relative">
            <input
              type={showDingKey ? 'text' : 'password'}
              value={dingKey}
              onChange={(e) => setDingKey(e.target.value)}
              placeholder={keyStatus?.DING_API_KEY?.configured ? '••••••• (leave blank to keep current)' : 'Paste your DingConnect API key'}
              className="w-full px-4 py-3 pr-12 rounded-xl border border-gray-200 bg-gray-50 text-sm font-mono text-gray-900 outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 transition-colors"
              autoComplete="off"
              spellCheck={false}
            />
            <button
              type="button"
              onClick={() => setShowDingKey((v) => !v)}
              className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
              tabIndex={-1}
            >
              {showDingKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
          <p className="text-xs text-gray-400">Found in your DingConnect account under API credentials.</p>
        </div>

        {/* DING_WEBHOOK_SECRET */}
        <div className="p-4 rounded-2xl bg-white border border-gray-100 shadow-sm space-y-2.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <KeyRound className="w-4 h-4 text-gray-500" />
              <label className="text-sm font-semibold text-gray-900">Ding Webhook Secret</label>
            </div>
            <KeyStatusIndicator name="DING_WEBHOOK_SECRET" status={keyStatus?.DING_WEBHOOK_SECRET} />
          </div>
          <div className="relative">
            <input
              type={showWebhook ? 'text' : 'password'}
              value={webhookSecret}
              onChange={(e) => setWebhookSecret(e.target.value)}
              placeholder={keyStatus?.DING_WEBHOOK_SECRET?.configured ? '••••••• (leave blank to keep current)' : 'Optional — set in DingConnect webhook settings'}
              className="w-full px-4 py-3 pr-12 rounded-xl border border-gray-200 bg-gray-50 text-sm font-mono text-gray-900 outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 transition-colors"
              autoComplete="off"
              spellCheck={false}
            />
            <button
              type="button"
              onClick={() => setShowWebhook((v) => !v)}
              className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
              tabIndex={-1}
            >
              {showWebhook ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
          <p className="text-xs text-gray-400">Only needed if DingConnect sends a signature header with delivery webhooks.</p>
        </div>

        {/* Save result */}
        {saveResult && (
          <div className={`flex items-center gap-2 p-3 rounded-xl text-sm font-medium ${
            saveResult.ok
              ? 'bg-green-50 border border-green-200 text-green-700'
              : 'bg-red-50 border border-red-200 text-red-700'
          }`}>
            {saveResult.ok ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
            {saveResult.msg}
          </div>
        )}

        <button
          type="submit"
          disabled={saving}
          className="w-full py-3.5 rounded-xl bg-blue-600 text-white font-bold flex items-center justify-center gap-2 hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-blue-600/20"
        >
          {saving ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          {saving ? 'Saving...' : 'Save Keys Securely'}
        </button>
      </form>

      <p className="text-xs text-gray-400 text-center pb-2">
        Keys are stored in a server-side table inaccessible from the browser.
        They take effect immediately on the next top-up.
      </p>
    </div>
  );
}

// ─── Dashboard Panel ─────────────────────────────────────────────────────────

function DashboardPanel() {
  const [balance, setBalance] = useState<DingBalance | null>(null);
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState('');

  const fetchAll = useCallback(async () => {
    try {
      const [balanceRes, statsRes, recentRes] = await Promise.all([
        supabase.functions.invoke('admin', { body: { action: 'balance' } }),
        supabase.functions.invoke('admin', { body: { action: 'stats' } }),
        supabase.functions.invoke('admin', { body: { action: 'recent', limit: 20 } }),
      ]);

      if (balanceRes.data) setBalance(balanceRes.data as DingBalance);
      if (statsRes.data) setStats(statsRes.data as AdminStats);
      if (recentRes.data?.transactions) setTransactions(recentRes.data.transactions as Transaction[]);

      const anyError = balanceRes.error || statsRes.error || recentRes.error;
      setError(anyError ? anyError.message : '');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load admin data');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    fetchAll();
    const interval = setInterval(fetchAll, 15000);
    return () => clearInterval(interval);
  }, [fetchAll]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-16">
        <RefreshCw className="w-7 h-7 text-blue-600 animate-spin mb-3" />
        <p className="text-sm text-gray-500">Loading dashboard...</p>
      </div>
    );
  }

  return (
    <div>
      {error && (
        <div className="mb-4 p-3 rounded-xl bg-red-50 border border-red-200 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
          <p className="text-sm text-red-700">{error}</p>
        </div>
      )}

      {/* DingConnect Balance Card */}
      <div className="mb-5 p-5 rounded-2xl bg-gradient-to-br from-blue-600 to-blue-800 shadow-lg shadow-blue-600/20">
        <div className="flex items-center gap-2 mb-2">
          <Wallet className="w-5 h-5 text-blue-100" />
          <p className="text-sm font-medium text-blue-100">DingConnect Balance</p>
        </div>
        {balance?.balance !== null && balance?.balance !== undefined ? (
          <p className="text-3xl font-bold text-white">
            {formatEur(balance.balance)}
            <span className="text-lg text-blue-200 ml-1">{balance.currency}</span>
          </p>
        ) : (
          <div>
            <p className="text-lg font-bold text-white">Unavailable</p>
            {balance?.error && <p className="text-xs text-blue-200 mt-1">{balance.error}</p>}
          </div>
        )}
        <p className="text-xs text-blue-300 mt-2">Auto-deducted for each successful top-up</p>
      </div>

      {/* Stats Grid */}
      {stats && (
        <>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
            <StatCard icon={<CheckCircle2 className="w-4 h-4 text-green-600" />} label="Completed" value={stats.completed} bg="bg-green-50" />
            <StatCard icon={<XCircle className="w-4 h-4 text-red-600" />} label="Failed" value={stats.failed} bg="bg-red-50" />
            <StatCard icon={<Clock className="w-4 h-4 text-amber-600" />} label="Pending" value={stats.pending} bg="bg-amber-50" />
            <StatCard icon={<RefreshCw className="w-4 h-4 text-blue-600" />} label="Refunded" value={stats.refunded} bg="bg-blue-50" />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
            <div className="p-4 rounded-2xl bg-white border border-gray-100 shadow-sm">
              <div className="flex items-center gap-2 mb-1">
                <TrendingUp className="w-4 h-4 text-green-600" />
                <p className="text-xs font-medium text-gray-500">Total Revenue</p>
              </div>
              <p className="text-xl font-bold text-gray-900">{formatEur(stats.total_revenue_eur)}</p>
            </div>
            <div className="p-4 rounded-2xl bg-white border border-gray-100 shadow-sm">
              <div className="flex items-center gap-2 mb-1">
                <Wallet className="w-4 h-4 text-orange-600" />
                <p className="text-xs font-medium text-gray-500">Ding Cost</p>
              </div>
              <p className="text-xl font-bold text-gray-900">{formatEur(stats.total_cost_eur)}</p>
            </div>
            <div className="p-4 rounded-2xl bg-gradient-to-br from-green-50 to-emerald-50 border border-green-200">
              <div className="flex items-center gap-2 mb-1">
                <TrendingUp className="w-4 h-4 text-green-600" />
                <p className="text-xs font-medium text-green-700">Net Profit</p>
              </div>
              <p className="text-xl font-bold text-green-800">{formatEur(stats.net_profit_eur)}</p>
            </div>
          </div>

          {stats.total_refunded_eur > 0 && (
            <div className="mb-5 p-3 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-between">
              <span className="text-sm text-blue-700 font-medium">Total Refunded to Customers</span>
              <span className="font-bold text-blue-800">{formatEur(stats.total_refunded_eur)}</span>
            </div>
          )}
        </>
      )}

      {/* Recent Transactions */}
      <div className="flex items-center gap-2 mb-3">
        <h3 className="font-bold text-gray-900">Recent Transactions</h3>
        <span className="text-xs text-gray-400">({transactions.length})</span>
      </div>

      <div className="space-y-2">
        {transactions.length === 0 ? (
          <div className="p-8 rounded-2xl bg-white border border-gray-100 text-center">
            <p className="text-sm text-gray-400">No transactions yet</p>
          </div>
        ) : (
          transactions.map((tx) => {
            const operator = getOperator(tx.operator_id);
            return (
              <div key={tx.id} className="p-3.5 rounded-2xl bg-white border border-gray-100 shadow-sm">
                <div className="flex items-center justify-between gap-3 mb-2">
                  <div className="flex items-center gap-2.5 min-w-0">
                    {operator && (
                      <div
                        className="w-16 h-8 rounded-lg overflow-hidden shrink-0 flex items-center justify-center px-1"
                        style={{ backgroundColor: operator.colorLight }}
                      >
                        <OperatorLogo operatorId={operator.id} className="w-full h-full" />
                      </div>
                    )}
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-gray-900" dir="ltr">{tx.amount_afn} AFN</p>
                      <p className="text-xs text-gray-500" dir="ltr">{tx.phone_number}</p>
                    </div>
                  </div>
                  <StatusBadge status={tx.status} />
                </div>
                <div className="flex items-center justify-between text-xs text-gray-400">
                  <span dir="ltr">{formatTime(tx.created_at)}</span>
                  <span className="font-medium text-gray-600" dir="ltr">{formatEur(tx.amount_eur)}</span>
                </div>
                {tx.refund_status === 'succeeded' && (
                  <div className="mt-2 flex items-center gap-1.5 text-xs text-blue-600">
                    <RefreshCw className="w-3 h-3" />
                    Auto-refunded to customer
                  </div>
                )}
                {tx.topup_error && tx.status === 'failed' && (
                  <div className="mt-2 text-xs text-red-500 break-words" style={{ overflowWrap: 'break-word' }}>
                    {tx.topup_error}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      <p className="text-xs text-gray-400 text-center mt-6">
        Auto-refreshes every 15 seconds
      </p>
    </div>
  );
}

// ─── Main AdminView ───────────────────────────────────────────────────────────

interface Props {
  onBack: () => void;
}

export function AdminView({ onBack }: Props) {
  const [unlocked, setUnlocked] = useState(() => {
    try { return sessionStorage.getItem(PIN_STORAGE_KEY) === '1'; } catch { return false; }
  });
  const [tab, setTab] = useState<'dashboard' | 'settings'>('dashboard');
  const [refreshing, setRefreshing] = useState(false);

  if (!unlocked) {
    return (
      <section className="mt-4">
        <button onClick={onBack} className="flex items-center gap-1.5 text-sm font-medium text-blue-600 hover:text-blue-700 mb-4 transition-colors">
          <ArrowLeft className="w-4 h-4" />
          Back to App
        </button>
        <PinGate onUnlock={() => setUnlocked(true)} />
      </section>
    );
  }

  return (
    <section className="mt-4">
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-2">
          <button onClick={onBack} className="flex items-center gap-1.5 text-sm font-medium text-blue-600 hover:text-blue-700 transition-colors">
            <ArrowLeft className="w-4 h-4" />
            Back
          </button>
        </div>
        <div className="flex items-center gap-2">
          {tab === 'dashboard' && (
            <button
              onClick={() => { setRefreshing(true); setTimeout(() => setRefreshing(false), 500); }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-50 text-blue-600 text-xs font-semibold hover:bg-blue-100 transition-colors"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />
              Refresh
            </button>
          )}
          <button
            onClick={() => { try { sessionStorage.removeItem(PIN_STORAGE_KEY); } catch { /**/ } setUnlocked(false); }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gray-100 text-gray-500 text-xs font-semibold hover:bg-gray-200 transition-colors"
          >
            <Lock className="w-3.5 h-3.5" />
            Lock
          </button>
        </div>
      </div>

      {/* Tab bar */}
      <div className="flex items-center gap-1 p-1 rounded-xl bg-gray-100 mb-5">
        <button
          onClick={() => setTab('dashboard')}
          className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-lg text-sm font-semibold transition-all ${
            tab === 'dashboard' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          Dashboard
        </button>
        <button
          onClick={() => setTab('settings')}
          className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-lg text-sm font-semibold transition-all ${
            tab === 'settings' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          <Settings className="w-4 h-4" />
          API Keys
        </button>
      </div>

      {tab === 'dashboard' ? <DashboardPanel /> : <SettingsPanel />}
    </section>
  );
}
