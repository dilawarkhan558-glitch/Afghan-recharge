interface LogoProps {
  className?: string;
}

// Roshan — red wordmark-style logo with stylized "R" and dot
export function RoshanLogo({ className = '' }: LogoProps) {
  return (
    <svg viewBox="0 0 160 80" className={className} xmlns="http://www.w3.org/2000/svg">
      {/* Roshan "R" mark */}
      <path
        d="M10 12 L10 68 M10 12 L34 12 C44 12 52 19 52 28 C52 37 44 44 34 44 L10 44 M28 44 L52 68"
        stroke="#E2231A"
        strokeWidth="8"
        fill="none"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="55" cy="18" r="5" fill="#E2231A" />
      {/* Wordmark */}
      <text x="68" y="48" fontSize="24" fontWeight="800" fill="#E2231A" fontFamily="Arial, sans-serif" letterSpacing="-0.5">Roshan</text>
    </svg>
  );
}

// Etisalat — green logo with stylized "ات" calligraphy-inspired mark + wordmark
export function EtisalatLogo({ className = '' }: LogoProps) {
  return (
    <svg viewBox="0 0 160 80" className={className} xmlns="http://www.w3.org/2000/svg">
      {/* Stylized calligraphy mark */}
      <path
        d="M8 44 C8 32 18 24 30 24 C42 24 52 32 52 44 M8 44 L8 60 M8 52 L52 52 M52 44 L52 60"
        stroke="#7B9317"
        strokeWidth="7"
        fill="none"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M58 30 L58 60 M58 30 C66 25 78 25 78 34 L78 60"
        stroke="#7B9317"
        strokeWidth="6"
        fill="none"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {/* Wordmark */}
      <text x="88" y="48" fontSize="20" fontWeight="800" fill="#7B9317" fontFamily="Arial, sans-serif" letterSpacing="-0.5">etisalat</text>
    </svg>
  );
}

// AWCC — wireless signal waves + wordmark, deep blue
export function AwccLogo({ className = '' }: LogoProps) {
  return (
    <svg viewBox="0 0 160 80" className={className} xmlns="http://www.w3.org/2000/svg">
      {/* Signal waves */}
      <circle cx="18" cy="58" r="6" fill="#004B8B" />
      <path d="M6 48 A20 20 0 0 1 30 48" stroke="#004B8B" strokeWidth="5" fill="none" strokeLinecap="round" />
      <path d="M0 38 A34 34 0 0 1 36 38" stroke="#004B8B" strokeWidth="5" fill="none" strokeLinecap="round" opacity="0.7" />
      <path d="M-5 29 A46 46 0 0 1 41 29" stroke="#004B8B" strokeWidth="4" fill="none" strokeLinecap="round" opacity="0.4" />
      {/* Wordmark */}
      <text x="48" y="45" fontSize="22" fontWeight="800" fill="#004B8B" fontFamily="Arial, sans-serif" letterSpacing="-0.5">AWCC</text>
      <text x="48" y="64" fontSize="11" fontWeight="600" fill="#004B8B" fontFamily="Arial, sans-serif" opacity="0.7">Afghan Wireless</text>
    </svg>
  );
}

// Salaam Telecom — green greeting mark + wordmark
export function SalaamLogo({ className = '' }: LogoProps) {
  return (
    <svg viewBox="0 0 160 80" className={className} xmlns="http://www.w3.org/2000/svg">
      {/* Greeting/handshake arc mark */}
      <path
        d="M6 38 L36 38 C48 38 56 44 56 52 C56 60 48 64 36 64 L6 64"
        stroke="#00803F"
        strokeWidth="7"
        fill="none"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M18 38 C18 28 28 22 38 22 C48 22 56 28 56 38"
        stroke="#00803F"
        strokeWidth="6"
        fill="none"
        strokeLinecap="round"
      />
      <circle cx="64" cy="26" r="4.5" fill="#00803F" />
      {/* Wordmark */}
      <text x="74" y="42" fontSize="18" fontWeight="800" fill="#00803F" fontFamily="Arial, sans-serif">Salaam</text>
      <text x="74" y="60" fontSize="12" fontWeight="600" fill="#00803F" fontFamily="Arial, sans-serif" opacity="0.7">Telecom</text>
    </svg>
  );
}

// MTN Afghanistan — yellow background rectangle with MTN's iconic "ayoba" oval + blue wordmark
export function MtnLogo({ className = '' }: LogoProps) {
  return (
    <svg viewBox="0 0 160 80" className={className} xmlns="http://www.w3.org/2000/svg">
      <rect x="0" y="0" width="160" height="80" rx="12" fill="#FFCC00" />
      {/* MTN's distinctive oval/ellipse motif */}
      <ellipse cx="36" cy="40" rx="28" ry="14" fill="none" stroke="#005A9C" strokeWidth="3" transform="rotate(-15 36 40)" opacity="0.35" />
      <ellipse cx="36" cy="40" rx="22" ry="11" fill="none" stroke="#005A9C" strokeWidth="3" transform="rotate(-15 36 40)" opacity="0.6" />
      <text
        x="36"
        y="47"
        textAnchor="middle"
        fontSize="22"
        fontWeight="900"
        fill="#005A9C"
        fontFamily="Arial, sans-serif"
      >
        MTN
      </text>
      <text x="78" y="36" fontSize="14" fontWeight="800" fill="#005A9C" fontFamily="Arial, sans-serif">MTN</text>
      <text x="78" y="54" fontSize="11" fontWeight="600" fill="#005A9C" fontFamily="Arial, sans-serif" opacity="0.8">Afghanistan</text>
    </svg>
  );
}

const LOGO_MAP: Record<string, (props: LogoProps) => JSX.Element> = {
  roshan: RoshanLogo,
  etisalat: EtisalatLogo,
  awcc: AwccLogo,
  salaam: SalaamLogo,
  mtn: MtnLogo,
};

export function OperatorLogo({ operatorId, className }: { operatorId: string; className?: string }) {
  const Logo = LOGO_MAP[operatorId];
  if (!Logo) return null;
  return <Logo className={className} />;
}
