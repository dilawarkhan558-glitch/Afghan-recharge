import { useState, useRef, useEffect } from 'react';
import { Globe, ChevronDown, ShieldCheck, Check, Zap } from 'lucide-react';
import { useI18n, LANGUAGES } from '@/lib/i18n';
import type { Language } from '@/lib/i18n/types';

export function Header() {
  const { lang, t, setLang } = useI18n();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const currentLang = LANGUAGES.find((l) => l.code === lang)!;

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md shadow-sm">
      {/* Afghan flag stripe at very top */}
      <div className="h-1.5 flag-stripe-horizontal" />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-3">
        <div className="flex items-center justify-between gap-3">
          {/* Logo */}
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="flex flex-col rounded-xl overflow-hidden shadow-md shrink-0">
              <div className="w-10 h-3.33 bg-afghan-black" />
              <div className="w-10 h-3.33 bg-afghan-red" />
              <div className="w-10 h-3.34 bg-afghan-green" />
            </div>
            <div className="min-w-0">
              <h1 className="text-base font-bold text-gray-900 truncate leading-tight"><span className="mr-1">🇦🇫</span>{t.appName}</h1>
              <p className="text-xs text-gray-500 truncate leading-tight hidden sm:block">{t.tagline}</p>
            </div>
          </div>

          {/* Language Switcher */}
          <div className="relative shrink-0" ref={dropdownRef}>
            <button
              onClick={() => setDropdownOpen((v) => !v)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-gray-200 bg-white hover:bg-gray-50 hover:border-gray-300 transition-all text-sm font-medium text-gray-700 shadow-sm"
            >
              <Globe className="w-4 h-4 text-afghan-green shrink-0" />
              <span className="hidden sm:inline whitespace-nowrap">{currentLang.nativeLabel}</span>
              <span className="sm:hidden">{currentLang.flag}</span>
              <ChevronDown className={`w-3.5 h-3.5 text-gray-400 transition-transform shrink-0 ${dropdownOpen ? 'rotate-180' : ''}`} />
            </button>

            {dropdownOpen && (
              <div className="absolute end-0 mt-2 w-44 rounded-xl border border-gray-100 bg-white shadow-xl shadow-gray-200/50 overflow-hidden">
                {LANGUAGES.map((l) => (
                  <button
                    key={l.code}
                    onClick={() => {
                      setLang(l.code as Language);
                      setDropdownOpen(false);
                    }}
                    className={`w-full flex items-center justify-between gap-2 px-4 py-2.5 text-sm transition-colors ${
                      lang === l.code ? 'bg-afghan-green-light text-afghan-green-dark font-semibold' : 'text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    <span className="flex items-center gap-2.5 min-w-0">
                      <span className="text-xs font-bold text-gray-400 w-6 shrink-0">{l.flag}</span>
                      <span className="truncate">{l.nativeLabel}</span>
                    </span>
                    {lang === l.code && <Check className="w-4 h-4 text-afghan-green shrink-0" />}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Trust Badge */}
      <div className="bg-gradient-to-r from-afghan-green-light to-afghan-red-light border-t border-gray-100/50">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-2">
          <div className="flex flex-row items-center justify-center gap-2 text-xs sm:text-sm flex-nowrap">
            <ShieldCheck className="w-4 h-4 text-afghan-green shrink-0" />
            <span className="font-medium text-gray-700 whitespace-nowrap">{t.trustBadge}</span>
          </div>
        </div>
      </div>
    </header>
  );
}
