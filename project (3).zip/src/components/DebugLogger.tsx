import { useState, useEffect, useCallback, useRef } from 'react';
import { AlertTriangle, X, ChevronDown, ChevronUp, Trash2, WifiOff } from 'lucide-react';

interface LogEntry {
  id: number;
  type: 'error' | 'network';
  message: string;
  timestamp: string;
  stack?: string;
}

export function DebugLogger() {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [expanded, setExpanded] = useState(false);
  const [dismissed, setDismissed] = useState(false);
  const idCounter = useRef(0);

  const addLog = useCallback((type: LogEntry['type'], message: string, stack?: string) => {
    const entry: LogEntry = {
      id: ++idCounter.current,
      type,
      message,
      stack,
      timestamp: new Date().toLocaleTimeString(),
    };
    setLogs((prev) => [...prev.slice(-49), entry]);
    setDismissed(false);
  }, []);

  useEffect(() => {
    const handleError = (event: ErrorEvent) => {
      addLog('error', event.message || 'Unknown error', event.error?.stack);
    };

    const handleRejection = (event: PromiseRejectionEvent) => {
      const reason = event.reason;
      const msg =
        reason instanceof Error ? reason.message :
        typeof reason === 'string' ? reason :
        JSON.stringify(reason);
      addLog('error', `Unhandled promise rejection: ${msg}`, reason instanceof Error ? reason.stack : undefined);
    };

    window.addEventListener('error', handleError);
    window.addEventListener('unhandledrejection', handleRejection);

    const originalFetch = window.fetch;
    window.fetch = async function (...args: Parameters<typeof fetch>): Promise<Response> {
      try {
        const response = await originalFetch.apply(this, args);
        if (!response.ok) {
          const url = typeof args[0] === 'string' ? args[0] : (args[0] as Request).url || 'unknown';
          addLog('network', `Request failed: ${response.status} ${response.statusText} — ${url}`);
        }
        return response;
      } catch (err) {
        const url = typeof args[0] === 'string' ? args[0] : (args[0] as Request)?.url || 'unknown';
        addLog('network', `Network error: ${err instanceof Error ? err.message : String(err)} — ${url}`);
        throw err;
      }
    };

    return () => {
      window.removeEventListener('error', handleError);
      window.removeEventListener('unhandledrejection', handleRejection);
      window.fetch = originalFetch;
    };
  }, [addLog]);

  if (logs.length === 0 || dismissed) return null;

  const errorCount = logs.filter((l) => l.type === 'error').length;
  const networkCount = logs.filter((l) => l.type === 'network').length;

  return (
    <div className="fixed top-0 inset-x-0 z-[9999] shadow-lg">
      <div className="bg-red-600 text-white">
        <div className="max-w-5xl mx-auto px-4 py-2.5">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2 min-w-0">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span className="text-sm font-semibold truncate">
                {errorCount > 0 && `${errorCount} error${errorCount > 1 ? 's' : ''}`}
                {errorCount > 0 && networkCount > 0 && ' · '}
                {networkCount > 0 && `${networkCount} failed request${networkCount > 1 ? 's' : ''}`}
              </span>
            </div>
            <div className="flex items-center gap-1 shrink-0">
              <button
                onClick={() => setExpanded((v) => !v)}
                className="p-1.5 rounded hover:bg-white/20 transition-colors"
                aria-label={expanded ? 'Collapse' : 'Expand'}
              >
                {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
              <button
                onClick={() => setLogs([])}
                className="p-1.5 rounded hover:bg-white/20 transition-colors"
                aria-label="Clear"
              >
                <Trash2 className="w-4 h-4" />
              </button>
              <button
                onClick={() => setDismissed(true)}
                className="p-1.5 rounded hover:bg-white/20 transition-colors"
                aria-label="Dismiss"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {expanded && (
            <div className="mt-2 space-y-1.5 max-h-64 overflow-y-auto pb-2">
              {logs.map((log) => (
                <div
                  key={log.id}
                  className="bg-red-700/40 rounded-lg px-3 py-2 text-xs"
                >
                  <div className="flex items-start gap-2">
                    {log.type === 'network' ? (
                      <WifiOff className="w-3.5 h-3.5 mt-0.5 shrink-0" />
                    ) : (
                      <AlertTriangle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
                    )}
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 mb-0.5">
                        <span className="font-mono text-[10px] opacity-70">{log.timestamp}</span>
                        <span className="px-1.5 py-0.5 rounded bg-white/20 text-[10px] font-bold uppercase">
                          {log.type}
                        </span>
                      </div>
                      <p className="font-mono break-all leading-relaxed">{log.message}</p>
                      {log.stack && (
                        <pre className="mt-1 font-mono text-[10px] opacity-70 whitespace-pre-wrap break-all max-h-20 overflow-y-auto">
                          {log.stack.split('\n').slice(0, 5).join('\n')}
                        </pre>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}


