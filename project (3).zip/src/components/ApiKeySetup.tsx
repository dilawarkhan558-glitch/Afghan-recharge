import { useState, useEffect, useCallback } from 'react';
import { KeyRound, Save, CheckCircle2, AlertCircle, Eye, EyeOff, RefreshCw, ShieldCheck } from 'lucide-react';
import { supabase } from '@/lib/supabase';

export function ApiKeySetup() {
  const [apiKey, setApiKey] = useState('');
  const [showKey, setShowKey] = useState(false);
  const [saving, setSaving] = useState(false);
  const [result, setResult] = useState<{ ok: boolean; msg: string } | null>(null);
  const [configured, setConfigured] = useState<boolean | null>(null);
  const [checking, setChecking] = useState(true);

  const checkStatus = useCallback(async () => {
    try {
      const { data } = await supabase.functions.invoke('admin', { body: { action: 'get_settings' } });
      if (data) {
        const status = data as { DING_API_KEY: { configured: boolean } };
        setConfigured(status.DING_API_KEY?.configured ?? false);
      }
    } catch {
      // ignore
    } finally {
      setChecking(false);
    }
  }, []);

  useEffect(() => { checkStatus(); }, [checkStatus]);

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    if (!apiKey.trim() || apiKey.trim().length < 4) {
      setResult({ ok: false, msg: 'Please enter a valid API key.' });
      return;
    }
    setSaving(true);
    setResult(null);
    try {
      const { data, error } = await supabase.functions.invoke('admin', {
        body: { action: 'save_settings', settings: { DING_API_KEY: apiKey.trim() } },
      });
      if (error) throw error;
      const res = data as { ok: boolean; saved: string[]; errors: string[] };
      if (res.ok) {
        setResult({ ok: true, msg: 'API key saved securely.' });
        setApiKey('');
        setShowKey(false);
        await checkStatus();
      } else {
        setResult({ ok: false, msg: res.errors.join(', ') || 'Save failed.' });
      }
    } catch (err) {
      setResult({ ok: false, msg: err instanceof Error ? err.message : 'Save failed.' });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="mt-6 p-4 rounded-2xl bg-white border border-gray-100 shadow-sm">
      <div className="flex items-center gap-2 mb-3">
        <KeyRound className="w-4 h-4 text-gray-500" />
        <h3 className="text-sm font-bold text-gray-900">DingConnect API Key</h3>
        {!checking && (
          configured ? (
            <span className="flex items-center gap-1 text-xs font-semibold text-green-600 ml-auto">
              <ShieldCheck className="w-3.5 h-3.5" />
              Configured
            </span>
          ) : (
            <span className="flex items-center gap-1 text-xs font-semibold text-amber-600 ml-auto">
              <AlertCircle className="w-3.5 h-3.5" />
              Not set
            </span>
          )
        )}
      </div>

      <form onSubmit={handleSave} className="space-y-3">
        <div className="relative">
          <input
            type={showKey ? 'text' : 'password'}
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
            placeholder={configured ? '••••••• (enter new key to replace)' : 'Paste your DingConnect API key'}
            className="w-full px-4 py-3 pr-11 rounded-xl border border-gray-200 bg-gray-50 text-sm font-mono text-gray-900 outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 transition-colors"
            autoComplete="off"
            spellCheck={false}
          />
          <button
            type="button"
            onClick={() => setShowKey((v) => !v)}
            className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
            tabIndex={-1}
          >
            {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </button>
        </div>

        {result && (
          <div className={`flex items-center gap-2 p-2.5 rounded-lg text-xs font-medium ${
            result.ok
              ? 'bg-green-50 border border-green-200 text-green-700'
              : 'bg-red-50 border border-red-200 text-red-700'
          }`}>
            {result.ok ? <CheckCircle2 className="w-3.5 h-3.5 shrink-0" /> : <AlertCircle className="w-3.5 h-3.5 shrink-0" />}
            {result.msg}
          </div>
        )}

        <button
          type="submit"
          disabled={saving}
          className="w-full py-3 rounded-xl bg-blue-600 text-white text-sm font-bold flex items-center justify-center gap-2 hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {saving ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          {saving ? 'Saving...' : 'Save Key Securely'}
        </button>
      </form>

      <p className="text-xs text-gray-400 mt-3 text-center">
        Stored server-side — never visible to customers.
      </p>
    </div>
  );
}
