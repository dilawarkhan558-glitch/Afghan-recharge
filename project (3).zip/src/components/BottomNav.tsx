import { Home, Clock, Bell, Settings } from 'lucide-react';

export type Tab = 'recharge' | 'history' | 'notifications' | 'settings';

interface Props {
  active: Tab;
  onChange: (tab: Tab) => void;
}

const items: { key: Tab; label: string; icon: typeof Home }[] = [
  { key: 'recharge', label: 'Home', icon: Home },
  { key: 'history', label: 'History', icon: Clock },
  { key: 'notifications', label: 'Alerts', icon: Bell },
  { key: 'settings', label: 'Settings', icon: Settings },
];

export function BottomNav({ active, onChange }: Props) {
  return (
    <nav className="fixed bottom-0 inset-x-0 z-30 bg-white/95 backdrop-blur-md border-t border-gray-100 shadow-[0_-4px_20px_rgba(0,0,0,0.06)] pb-safe">
      {/* Afghan flag accent line */}
      <div className="h-0.5 flag-stripe-horizontal opacity-80" />

      <div className="max-w-5xl mx-auto px-4">
        <div className="flex items-center justify-around h-16">
          {items.map((item) => {
            const Icon = item.icon;
            const isActive = active === item.key;
            return (
              <button
                key={item.key}
                onClick={() => onChange(item.key)}
                className={`relative flex flex-col items-center justify-center gap-1 flex-1 h-full transition-colors ${
                  isActive ? 'text-afghan-red' : 'text-gray-400 hover:text-gray-600'
                }`}
              >
                {isActive && (
                  <span className="absolute top-0 w-12 h-1 rounded-b-full bg-afghan-red" />
                )}
                <Icon
                  className={`w-5 h-5 transition-transform ${isActive ? 'scale-110' : ''}`}
                  fill={isActive ? 'currentColor' : 'none'}
                />
                <span className="text-xs font-medium">{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
