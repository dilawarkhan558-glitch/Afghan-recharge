import { useState, useEffect, useCallback } from 'react';
import {
  Settings as SettingsIcon,
  Globe,
  Check,
  KeyRound,
  Eye,
  EyeOff,
  Save,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  Bell,
  Smartphone,
  Info,
  Lock,
  CreditCard,
  Download,
  Plug,
  Server,
} from 'lucide-react';
import { useI18n, LANGUAGES } from '@/lib/i18n';
import type { Language } from '@/lib/i18n/types';
import { supabase } from '@/lib/supabase';

const WHATSAPP_URL =
  'https://wa.me/393512121290?text=' + encodeURIComponent('Salam, Afghan Topup help');
const EMAIL_URL = 'mailto:afghantopup.support@gmail.com';

interface SettingStatus {
  configured: boolean;
  source: 'database' | 'environment' | 'default' | 'none';
  masked?: string;
  value?: string;
}

interface SettingsResponse {
  DING_API_KEY: SettingStatus;
  DING_API_BASE: SettingStatus;
  DING_WEBHOOK_SECRET: SettingStatus;
}

type ConnStatus = 'idle' | 'testing' | 'connected' | 'failed' | 'no_key';

interface ConnResult {
  success: boolean;
  status: string;
  message: string;
  balance?: number;
  currency?: string;
}

export function SettingsView({ onShowPrivacy }: { onShowPrivacy: () => void }) {
  const { lang, t, setLang } = useI18n();

  // Form fields
  const [dingApiBase, setDingApiBase] = useState('');
  const [dingApiKey, setDingApiKey] = useState('');
  const [dingWebhookSecret, setDingWebhookSecret] = useState('');
  const [showApiKey, setShowApiKey] = useState(false);
  const [showWebhook, setShowWebhook] = useState(false);

  // Save state
  const [saving, setSaving] = useState(false);
  const [saveResult, setSaveResult] = useState<{ ok: boolean; msg: string } | null>(null);

  // Settings status from server
  const [settingsStatus, setSettingsStatus] = useState<SettingsResponse | null>(null);
  const [loadingStatus, setLoadingStatus] = useState(true);

  // Test connection state
  const [connStatus, setConnStatus] = useState<ConnStatus>('idle');
  const [connMessage, setConnMessage] = useState('');

  const loadStatus = useCallback(async () => {
    try {
      const { data } = await supabase.functions.invoke('admin', {
        body: { action: 'get_settings' },
      });
      if (data) {
        setSettingsStatus(data as SettingsResponse);
      }
    } catch {
      // ignore
    }
    setLoadingStatus(false);
  }, []);

  useEffect(() => {
    loadStatus();
  }, [loadStatus]);

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    const settings: Record<string, string> = {};
    if (dingApiBase.trim()) settings['DING_API_BASE'] = dingApiBase.trim();
    if (dingApiKey.trim()) settings['DING_API_KEY'] = dingApiKey.trim();
    if (dingWebhookSecret.trim()) settings['DING_WEBHOOK_SECRET'] = dingWebhookSecret.trim();

    if (Object.keys(settings).length === 0) {
      setSaveResult({ ok: false, msg: 'Enter at least one value to save.' });
      return;
    }

    setSaving(true);
    setSaveResult(null);
    setConnStatus('idle');
    try {
      const { data, error } = await supabase.functions.invoke('admin', {
        body: { action: 'save_settings', settings },
      });
      if (error) throw error;
      const res = data as { ok: boolean; saved: string[]; errors: string[] };
      if (res.ok) {
        setSaveResult({ ok: true, msg: `Saved: ${res.saved.join(', ')}` });
        setDingApiBase('');
        setDingApiKey('');
        setDingWebhookSecret('');
        await loadStatus();
      } else {
        setSaveResult({ ok: false, msg: res.errors?.join(', ') || 'Save failed.' });
      }
    } catch (err) {
      setSaveResult({ ok: false, msg: err instanceof Error ? err.message : 'Save failed.' });
    } finally {
      setSaving(false);
    }
  }

  async function handleTestConnection() {
    setConnStatus('testing');
    setConnMessage('');

    try {
      const payload: Record<string, unknown> = { action: 'test_connection' };
      // If user typed new values in the form, test those instead of saved ones
      if (dingApiKey.trim()) payload.api_key = dingApiKey.trim();
      if (dingApiBase.trim()) payload.api_base = dingApiBase.trim();

      const { data, error } = await supabase.functions.invoke('admin', {
        body: payload,
      });
      if (error) throw error;

      const result = data as ConnResult;
      if (result.success) {
        setConnStatus('connected');
        setConnMessage(result.message);
      } else if (result.status === 'no_key') {
        setConnStatus('no_key');
        setConnMessage(result.message);
      } else {
        setConnStatus('failed');
        setConnMessage(result.message);
      }
    } catch (err) {
      setConnStatus('failed');
      setConnMessage(err instanceof Error ? err.message : 'Connection test failed.');
    }
  }

  return (
    <section className="mt-6">
      <div className="flex items-center gap-2 mb-1">
        <SettingsIcon className="w-5 h-5 text-afghan-red" />
        <h2 className="text-lg font-bold text-gray-900">Settings</h2>
      </div>
      <p className="text-sm text-gray-500 mb-5">Manage your app preferences and API keys</p>

      {/* Ding API Configuration */}
      <div className="mb-4 p-4 sm:p-5 rounded-2xl bg-white border border-gray-100 shadow-sm">
        <div className="flex items-center gap-2 mb-1">
          <Server className="w-4 h-4 text-afghan-red" />
          <h3 className="text-sm font-bold text-gray-900">Ding API Configuration</h3>
        </div>
        <p className="text-xs text-gray-400 mb-4">
          Configure your DingConnect credentials. Values are stored securely server-side.
        </p>

        {/* Current values summary */}
        {!loadingStatus && settingsStatus && (
          <div className="mb-4 p-3 rounded-xl bg-gray-50 border border-gray-100 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-gray-500 font-medium">API Base</span>
              <span className="font-mono text-gray-700 text-end" dir="ltr">
                {settingsStatus.DING_API_BASE.value || 'Not set'}
              </span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-gray-500 font-medium">API Key</span>
              <span className="font-mono text-gray-700" dir="ltr">
                {settingsStatus.DING_API_KEY.masked || 'Not set'}
              </span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-gray-500 font-medium">Webhook Secret</span>
              <span className="font-mono text-gray-700" dir="ltr">
                {settingsStatus.DING_WEBHOOK_SECRET.masked || 'Not set'}
              </span>
            </div>
          </div>
        )}

        <form onSubmit={handleSave} className="space-y-4">
          {/* DING_API_BASE */}
          <div className="space-y-1.5">
            <label className="text-sm font-semibold text-gray-700 flex items-center gap-1.5">
              <Server className="w-3.5 h-3.5 text-gray-400" />
              DING_API_BASE
            </label>
            <input
              type="text"
              value={dingApiBase}
              onChange={(e) => setDingApiBase(e.target.value)}
              placeholder="https://api.dingconnect.com"
              className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 text-sm font-mono text-gray-900 outline-none focus:border-afghan-red focus:ring-2 focus:ring-afghan-red/10 transition-colors"
              autoComplete="off"
              spellCheck={false}
              dir="ltr"
            />
            <p className="text-xs text-gray-400">The base URL for DingConnect API calls.</p>
          </div>

          {/* DING_API_KEY */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-sm font-semibold text-gray-700 flex items-center gap-1.5">
                <KeyRound className="w-3.5 h-3.5 text-gray-400" />
                DING_API_KEY
              </label>
              {!loadingStatus && settingsStatus && (
                settingsStatus.DING_API_KEY.configured ? (
                  <span className="flex items-center gap-1 text-xs font-semibold text-afghan-green">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    {settingsStatus.DING_API_KEY.masked}
                  </span>
                ) : (
                  <span className="flex items-center gap-1 text-xs font-semibold text-amber-600">
                    <AlertCircle className="w-3.5 h-3.5" />
                    Not set
                  </span>
                )
              )}
            </div>
            <div className="relative">
              <input
                type={showApiKey ? 'text' : 'password'}
                value={dingApiKey}
                onChange={(e) => setDingApiKey(e.target.value)}
                placeholder="Enter your DingConnect API Key"
                className="w-full px-4 py-3 pr-11 rounded-xl border border-gray-200 bg-gray-50 text-sm font-mono text-gray-900 outline-none focus:border-afghan-red focus:ring-2 focus:ring-afghan-red/10 transition-colors"
                autoComplete="off"
                spellCheck={false}
                dir="ltr"
              />
              <button
                type="button"
                onClick={() => setShowApiKey((v) => !v)}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                tabIndex={-1}
              >
                {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <p className="text-xs text-gray-400">Leave blank to keep the current key unchanged.</p>
          </div>

          {/* DING_WEBHOOK_SECRET */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-sm font-semibold text-gray-700 flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-gray-400" />
                DING_WEBHOOK_SECRET
              </label>
              {!loadingStatus && settingsStatus && (
                settingsStatus.DING_WEBHOOK_SECRET.configured ? (
                  <span className="flex items-center gap-1 text-xs font-semibold text-afghan-green">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    {settingsStatus.DING_WEBHOOK_SECRET.masked}
                  </span>
                ) : (
                  <span className="text-xs font-semibold text-gray-400">Optional</span>
                )
              )}
            </div>
            <div className="relative">
              <input
                type={showWebhook ? 'text' : 'password'}
                value={dingWebhookSecret}
                onChange={(e) => setDingWebhookSecret(e.target.value)}
                placeholder="Enter webhook secret"
                className="w-full px-4 py-3 pr-11 rounded-xl border border-gray-200 bg-gray-50 text-sm font-mono text-gray-900 outline-none focus:border-afghan-red focus:ring-2 focus:ring-afghan-red/10 transition-colors"
                autoComplete="off"
                spellCheck={false}
                dir="ltr"
              />
              <button
                type="button"
                onClick={() => setShowWebhook((v) => !v)}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                tabIndex={-1}
              >
                {showWebhook ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <p className="text-xs text-gray-400">Only needed if DingConnect sends webhook signatures.</p>
          </div>

          {/* Save result */}
          {saveResult && (
            <div
              className={`flex items-center gap-2 p-3 rounded-xl text-sm font-medium ${
                saveResult.ok
                  ? 'bg-afghan-green-light border border-afghan-green/20 text-afghan-green-dark'
                  : 'bg-afghan-red-light border border-afghan-red/20 text-afghan-red'
              }`}
            >
              {saveResult.ok ? (
                <CheckCircle2 className="w-4 h-4 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 shrink-0" />
              )}
              {saveResult.msg}
            </div>
          )}

          {/* Action buttons */}
          <div className="flex flex-col sm:flex-row gap-3">
            <button
              type="submit"
              disabled={saving}
              className="flex-1 py-3 rounded-xl bg-afghan-red text-white text-sm font-bold flex items-center justify-center gap-2 hover:bg-afghan-red-dark transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {saving ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                <Save className="w-4 h-4" />
              )}
              {saving ? 'Saving...' : 'Save'}
            </button>
            <button
              type="button"
              onClick={handleTestConnection}
              disabled={connStatus === 'testing'}
              className="flex-1 py-3 rounded-xl border-2 border-afghan-green text-afghan-green text-sm font-bold flex items-center justify-center gap-2 hover:bg-afghan-green-light transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {connStatus === 'testing' ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                <Plug className="w-4 h-4" />
              )}
              {connStatus === 'testing' ? 'Testing...' : 'Test Connection'}
            </button>
          </div>
        </form>

        {/* Connection test result */}
        {connStatus !== 'idle' && connStatus !== 'testing' && (
          <div
            className={`mt-4 flex items-start gap-2.5 p-3 rounded-xl text-sm font-medium ${
              connStatus === 'connected'
                ? 'bg-afghan-green-light border border-afghan-green/20 text-afghan-green-dark'
                : connStatus === 'no_key'
                ? 'bg-amber-50 border border-amber-200 text-amber-700'
                : 'bg-afghan-red-light border border-afghan-red/20 text-afghan-red'
            }`}
          >
            {connStatus === 'connected' ? (
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
            ) : (
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            )}
            <div>
              <p className="font-semibold">
                {connStatus === 'connected'
                  ? 'Connection Successful'
                  : connStatus === 'no_key'
                  ? 'No API Key'
                  : 'Authentication Failed'}
              </p>
              <p className="text-xs mt-0.5 break-words" style={{ overflowWrap: 'break-word' }}>
                {connMessage}
              </p>
            </div>
          </div>
        )}

        {/* Status indicator */}
        {!loadingStatus && settingsStatus && (
          <div className="mt-4 flex items-center gap-2 text-xs">
            <span className={`w-2.5 h-2.5 rounded-full ${
              settingsStatus.DING_API_KEY.configured ? 'bg-afghan-green' : 'bg-afghan-red'
            }`} />
            <span className="text-gray-500">
              {settingsStatus.DING_API_KEY.configured
                ? 'API key is configured'
                : 'API key is not configured — top-ups will fail'}
            </span>
          </div>
        )}
      </div>

      {/* Language */}
      <div className="mb-4 p-4 rounded-2xl bg-white border border-gray-100 shadow-sm">
        <div className="flex items-center gap-2 mb-3">
          <Globe className="w-4 h-4 text-gray-500" />
          <h3 className="text-sm font-bold text-gray-900">Language</h3>
        </div>
        <div className="space-y-2">
          {LANGUAGES.map((l) => (
            <button
              key={l.code}
              onClick={() => setLang(l.code as Language)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-sm transition-colors ${
                lang === l.code
                  ? 'bg-afghan-green-light text-afghan-green-dark font-semibold'
                  : 'text-gray-700 hover:bg-gray-50'
              }`}
            >
              <span className="flex items-center gap-2.5">
                <span className="text-xs font-bold text-gray-400 w-6">{l.flag}</span>
                {l.nativeLabel}
              </span>
              {lang === l.code && <Check className="w-4 h-4 text-afghan-green" />}
            </button>
          ))}
        </div>
      </div>

      {/* App Info */}
      <div className="mb-4 p-4 rounded-2xl bg-white border border-gray-100 shadow-sm">
        <div className="flex items-center gap-2 mb-3">
          <Info className="w-4 h-4 text-gray-500" />
          <h3 className="text-sm font-bold text-gray-900">About</h3>
        </div>
        <div className="space-y-2.5 text-sm">
          <div className="flex items-center justify-between">
            <span className="text-gray-500">Version</span>
            <span className="font-medium text-gray-900">1.0.0</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-gray-500">Platform</span>
            <span className="font-medium text-gray-900">Web · PWA</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-gray-500">Payment</span>
            <span className="font-medium text-gray-900 flex items-center gap-1">
              <CreditCard className="w-3.5 h-3.5 text-afghan-red" />
              Stripe
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-gray-500">Top-up Provider</span>
            <span className="font-medium text-gray-900">DingConnect</span>
          </div>
        </div>
      </div>

      {/* Support */}
      <div className="mb-4 p-4 rounded-2xl bg-white border border-gray-100 shadow-sm">
        <div className="flex items-center gap-2 mb-3">
          <Bell className="w-4 h-4 text-gray-500" />
          <h3 className="text-sm font-bold text-gray-900">Support</h3>
        </div>
        <a
          href={WHATSAPP_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-3 p-3 rounded-xl bg-gradient-to-r from-afghan-green to-afghan-green-dark text-white text-sm font-bold hover:shadow-lg transition-all mb-2"
        >
          <Smartphone className="w-4 h-4" />
          WhatsApp: +39 351 212 1290
        </a>
        <a
          href={EMAIL_URL}
          className="flex items-center gap-3 p-3 rounded-xl border border-gray-200 text-gray-700 text-sm font-bold hover:bg-gray-50 transition-all"
        >
          <Info className="w-4 h-4 text-afghan-red" />
          afghantopup.support@gmail.com
        </a>
      </div>

      {/* Download Project */}
      <div className="mb-4 p-4 rounded-2xl bg-white border border-gray-100 shadow-sm">
        <div className="flex items-center gap-2 mb-3">
          <Download className="w-4 h-4 text-gray-500" />
          <h3 className="text-sm font-bold text-gray-900">Download Project</h3>
        </div>
        <a
          href="/project.zip"
          download
          className="flex items-center justify-center gap-2 w-full py-3 rounded-xl bg-afghan-black text-white text-sm font-bold hover:bg-gray-800 transition-colors"
        >
          <Download className="w-4 h-4" />
          Download Source Code (ZIP)
        </a>
        <p className="text-xs text-gray-400 mt-2 text-center">
          Full project source
        </p>
      </div>

      {/* Privacy */}
      <div className="p-4 rounded-2xl bg-gray-50 border border-gray-100">
        <div className="flex items-start gap-2.5">
          <Lock className="w-4 h-4 text-gray-400 mt-0.5 shrink-0" />
          <div className="flex-1">
            <p className="text-xs text-gray-500 leading-relaxed mb-2">
              Your data is protected with 256-bit SSL encryption. Payment is processed by Stripe.
              Top-ups delivered via DingConnect. We never store your card details.
            </p>
            <button
              onClick={onShowPrivacy}
              className="text-xs font-semibold text-afghan-red hover:text-afghan-red-dark transition-colors"
            >
              Read full Privacy Policy →
            </button>
          </div>
        </div>
      </div>

      <p className="text-center text-xs text-gray-400 mt-6 mb-2">{t.poweredBy}</p>
    </section>
  );
}
