import { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { CheckCircle2, XCircle, Loader2, ArrowRight } from 'lucide-react';
import { useI18n } from '@/lib/i18n';
import { supabase } from '@/lib/supabase';
import { getOperator } from '@/lib/operators';
import { OperatorLogo } from './OperatorLogos';

interface Props {
  rechargeId: string;
  onDone: () => void;
  onHistoryChange: () => void;
}

interface RechargeStatus {
  status: string;
  payment_status: string | null;
  topup_status: string | null;
  topup_error: string | null;
  transaction_id: string | null;
  operator_id: string;
  phone_number: string;
  amount_afn: number;
  completed: boolean;
  failed: boolean;
  processing: boolean;
}

// Confetti pieces with Afghan flag colors
const CONFETTI_COLORS = ['#000000', '#D32011', '#007A36', '#FFD700', '#ffffff'];

function Confetti() {
  const pieces = useMemo(() => {
    return Array.from({ length: 60 }, (_, i) => {
      const left = Math.random() * 100;
      const delay = Math.random() * 2;
      const duration = 2.5 + Math.random() * 2;
      const color = CONFETTI_COLORS[i % CONFETTI_COLORS.length];
      const size = 6 + Math.random() * 8;
      const isCircle = Math.random() > 0.5;
      return { id: i, left, delay, duration, color, size, isCircle };
    });
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
      {pieces.map((p) => (
        <div
          key={p.id}
          className="confetti-piece"
          style={{
            left: `${p.left}%`,
            backgroundColor: p.color,
            width: `${p.size}px`,
            height: `${p.size}px`,
            borderRadius: p.isCircle ? '50%' : '2px',
            animationDelay: `${p.delay}s`,
            animationDuration: `${p.duration}s`,
          }}
        />
      ))}
    </div>
  );
}

export function RechargeStatusView({ rechargeId, onDone, onHistoryChange }: Props) {
  const { t } = useI18n();
  const [status, setStatus] = useState<RechargeStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [timedOut, setTimedOut] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const stopPolling = useCallback(() => {
    if (pollRef.current) {
      clearInterval(pollRef.current);
      pollRef.current = null;
    }
  }, []);

  useEffect(() => {
    const poll = async () => {
      try {
        const { data, error } = await supabase.functions.invoke(
          'ding-topup',
          { body: { action: 'check', recharge_id: rechargeId } },
        );

        if (error || !data) return;

        const statusData = data as RechargeStatus;
        setStatus(statusData);
        setLoading(false);

        if (statusData.completed) {
          stopPolling();
          setShowConfetti(true);
          onHistoryChange();
          setTimeout(() => setShowConfetti(false), 5000);
        } else if (statusData.failed) {
          stopPolling();
        }
      } catch {
        // Network error — keep polling
      }
    };

    poll();
    pollRef.current = setInterval(poll, 3000);
    const timeout = setTimeout(() => {
      stopPolling();
      setTimedOut(true);
    }, 120000);

    return () => {
      stopPolling();
      clearTimeout(timeout);
    };
  }, [rechargeId, stopPolling, onHistoryChange]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <Loader2 className="w-12 h-12 text-afghan-red animate-spin mb-4" />
        <p className="font-semibold text-gray-700">{t.paymentProcessing}</p>
      </div>
    );
  }

  if (!status) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <p className="text-sm text-gray-500 mb-4">{t.paymentError}</p>
        <button
          onClick={onDone}
          className="px-6 py-3 rounded-xl bg-afghan-red text-white font-bold hover:bg-afghan-red-dark transition-colors"
        >
          {t.done}
        </button>
      </div>
    );
  }

  const operator = getOperator(status.operator_id);

  // Success state
  if (status.completed) {
    return (
      <>
        {showConfetti && <Confetti />}
        <div className="flex flex-col items-center justify-center py-12 text-center px-4 animate-scale-in">
          <div className="w-20 h-20 mx-auto rounded-full bg-afghan-green-light flex items-center justify-center mb-4 relative">
            <CheckCircle2 className="w-12 h-12 text-afghan-green" />
            {/* Pulse ring */}
            <div className="absolute inset-0 rounded-full border-2 border-afghan-green/30 animate-ping" />
          </div>
          <h3 className="text-xl font-bold text-gray-900 mb-2">{t.paymentSuccess}</h3>
          <p className="text-sm text-gray-500 mb-6">{t.paymentSuccessDesc}</p>

          <div className="w-full max-w-sm space-y-2 p-4 rounded-xl bg-gray-50 mb-6">
            {operator && (
              <div className="flex items-center gap-3">
                <div className="w-20 h-10 rounded-lg overflow-hidden shrink-0 flex items-center justify-center px-1"
                  style={{ backgroundColor: operator.colorLight }}>
                  <OperatorLogo operatorId={operator.id} className="w-full h-full" />
                </div>
                <span className="font-semibold text-gray-900 text-sm">{operator.name}</span>
              </div>
            )}
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-500">{t.phoneNumber}</span>
              <span className="font-mono font-semibold text-gray-900" dir="ltr">{status.phone_number}</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-500">{t.amount}</span>
              <span className="font-semibold text-gray-900">{status.amount_afn} AFN</span>
            </div>
            {status.transaction_id && (
              <div className="flex items-center justify-between text-sm pt-2 border-t border-gray-200">
                <span className="text-gray-500 font-medium">Transaction ID</span>
                <span className="font-mono text-xs text-afghan-green font-bold" dir="ltr">{status.transaction_id}</span>
              </div>
            )}
          </div>

          <button
            onClick={onDone}
            className="w-full max-w-sm py-3.5 rounded-xl bg-gradient-to-r from-afghan-green to-afghan-green-dark text-white font-bold hover:shadow-lg transition-all"
          >
            {t.done}
          </button>
        </div>
      </>
    );
  }

  // Failed state
  if (status.failed) {
    const errorMsg = status.topup_error || t.paymentError;
    const paymentFailed = status.payment_status === 'failed';

    return (
      <div className="flex flex-col items-center justify-center py-12 text-center px-4 animate-scale-in">
        <div className="w-20 h-20 mx-auto rounded-full bg-afghan-red-light flex items-center justify-center mb-4">
          <XCircle className="w-12 h-12 text-afghan-red" />
        </div>
        <h3 className="text-xl font-bold text-gray-900 mb-2">
          {paymentFailed ? t.paymentError : t.paymentError}
        </h3>
        <p className="text-sm text-gray-500 mb-6 break-words">{errorMsg}</p>

        <div className="w-full max-w-sm space-y-2 p-4 rounded-xl bg-gray-50 mb-6">
          {operator && (
            <div className="flex items-center gap-3">
              <div className="w-20 h-10 rounded-lg overflow-hidden shrink-0 flex items-center justify-center px-1"
                style={{ backgroundColor: operator.colorLight }}>
                <OperatorLogo operatorId={operator.id} className="w-full h-full" />
              </div>
              <span className="font-semibold text-gray-900 text-sm">{operator.name}</span>
            </div>
          )}
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-500">{t.phoneNumber}</span>
            <span className="font-mono font-semibold text-gray-900" dir="ltr">{status.phone_number}</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-500">{t.amount}</span>
            <span className="font-semibold text-gray-900">{status.amount_afn} AFN</span>
          </div>
        </div>

        <button
          onClick={onDone}
          className="w-full max-w-sm py-3.5 rounded-xl bg-afghan-red text-white font-bold hover:bg-afghan-red-dark transition-colors"
        >
          {t.done}
        </button>
      </div>
    );
  }

  // Processing state
  return (
    <div className="flex flex-col items-center justify-center py-12 text-center px-4 animate-fade-in">
      <div className="w-20 h-20 mx-auto rounded-full bg-afghan-red-light flex items-center justify-center mb-4">
        <Loader2 className="w-12 h-12 text-afghan-red animate-spin" />
      </div>
      <h3 className="text-xl font-bold text-gray-900 mb-2">{t.paymentProcessing}</h3>
      <p className="text-sm text-gray-500 mb-6">{t.topupDelivering}</p>

      <div className="w-full max-w-sm space-y-2 p-4 rounded-xl bg-gray-50 mb-6">
        {operator && (
          <div className="flex items-center gap-3">
            <div className="w-20 h-10 rounded-lg overflow-hidden shrink-0 flex items-center justify-center px-1"
              style={{ backgroundColor: operator.colorLight }}>
              <OperatorLogo operatorId={operator.id} className="w-full h-full" />
            </div>
            <span className="font-semibold text-gray-900 text-sm">{operator.name}</span>
          </div>
        )}
        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-500">{t.phoneNumber}</span>
          <span className="font-mono font-semibold text-gray-900" dir="ltr">{status.phone_number}</span>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-500">{t.amount}</span>
          <span className="font-semibold text-gray-900">{status.amount_afn} AFN</span>
        </div>
      </div>

      {timedOut && (
        <p className="text-xs text-amber-600 mb-4">{t.statusTimeout}</p>
      )}

      <button
        onClick={onDone}
        className="flex items-center gap-2 text-sm font-medium text-afghan-red hover:text-afghan-red-dark transition-colors"
      >
        {t.backToRecharge}
        <ArrowRight className="w-4 h-4" />
      </button>
    </div>
  );
}
