import { useState, useEffect, useCallback } from 'react';
import { History as HistoryIcon, Receipt, Clock } from 'lucide-react';
import { useI18n } from '@/lib/i18n';
import { supabase } from '@/lib/supabase';
import { getOperator } from '@/lib/operators';
import { OperatorLogo } from './OperatorLogos';

interface RechargeRecord {
  id: string;
  operator_id: string;
  phone_number: string;
  amount_afn: number;
  service_fee_afn: number;
  status: string;
  payment_status: string | null;
  topup_status: string | null;
  topup_error: string | null;
  created_at: string;
}

interface Props {
  refreshKey: number;
}

export function HistoryView({ refreshKey }: Props) {
  const { t, dir } = useI18n();
  const [records, setRecords] = useState<RechargeRecord[]>([]);
  const [loading, setLoading] = useState(true);

  const loadHistory = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('recharges')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(50);

    if (!error && data) {
      setRecords(data as RechargeRecord[]);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    loadHistory();
  }, [loadHistory, refreshKey]);

  const statusStyles: Record<string, string> = {
    completed: 'bg-afghan-green-light text-afghan-green-dark',
    pending: 'bg-amber-100 text-amber-700',
    processing: 'bg-afghan-red-light text-afghan-red',
    failed: 'bg-afghan-red-light text-afghan-red',
  };

  const statusLabels: Record<string, string> = {
    completed: t.statusCompleted,
    pending: t.statusPending,
    processing: t.statusPending,
    failed: t.statusFailed,
  };

  function formatDate(iso: string): string {
    const d = new Date(iso);
    return d.toLocaleDateString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-3 border-gray-200 border-t-afghan-red rounded-full animate-spin" />
      </div>
    );
  }

  if (records.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <div className="w-20 h-20 rounded-full bg-gray-100 flex items-center justify-center mb-4">
          <Receipt className="w-10 h-10 text-gray-300" />
        </div>
        <h3 className="font-bold text-gray-900 text-lg mb-1">{t.historyEmpty}</h3>
        <p className="text-sm text-gray-500">{t.historyEmptyDesc}</p>
      </div>
    );
  }

  return (
    <section className="mt-6">
      <div className="flex items-center gap-2 mb-4">
        <HistoryIcon className="w-5 h-5 text-afghan-red" />
        <h2 className="text-lg font-bold text-gray-900">{t.history}</h2>
        <span className="text-sm text-gray-400 font-normal">({records.length})</span>
      </div>

      <div className="space-y-3">
        {records.map((rec) => {
          const op = getOperator(rec.operator_id);
          return (
            <div
              key={rec.id}
              className="flex items-center gap-3 p-3.5 rounded-2xl border border-gray-100 bg-white shadow-sm hover:shadow-md transition-shadow"
            >
              <div
                className="w-20 h-10 rounded-xl overflow-hidden shrink-0 flex items-center justify-center px-1"
                style={{ backgroundColor: op?.colorLight || '#f3f4f6' }}
              >
                {op && <OperatorLogo operatorId={op.id} className="w-full h-full" />}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-gray-900 text-sm break-words" style={{ overflowWrap: 'break-word' }}>
                    {op?.name || rec.operator_id}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded-full text-xs font-semibold ${statusStyles[rec.status] || 'bg-gray-100 text-gray-600'}`}
                  >
                    {statusLabels[rec.status] || rec.status}
                  </span>
                </div>
                <div className="flex items-center gap-2 mt-1 text-xs text-gray-500">
                  <span className="font-mono" dir="ltr">{rec.phone_number}</span>
                  <span className="text-gray-300">•</span>
                  <Clock className="w-3 h-3 shrink-0" />
                  <span className={dir === 'rtl' ? 'text-end' : ''}>{formatDate(rec.created_at)}</span>
                </div>
              </div>

              <div className="text-end shrink-0">
                <p className="font-bold text-gray-900">{rec.amount_afn}</p>
                <p className="text-xs text-gray-400">AFN</p>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
