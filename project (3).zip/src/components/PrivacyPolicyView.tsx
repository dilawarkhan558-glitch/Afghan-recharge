import { ArrowLeft } from 'lucide-react';

interface Props {
  onBack: () => void;
}

export function PrivacyPolicyView({ onBack }: Props) {
  return (
    <section className="mt-6 max-w-3xl mx-auto">
      <button
        onClick={onBack}
        className="flex items-center gap-1.5 text-sm font-medium text-afghan-red hover:text-afghan-red-dark mb-4 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        Back
      </button>

      <h1 className="text-2xl font-bold text-gray-900 mb-2">Privacy Policy</h1>
      <p className="text-sm text-gray-400 mb-6">Last updated: October 6, 2026</p>

      <div className="space-y-6 text-sm text-gray-700 leading-relaxed">
        <div>
          <h2 className="text-lg font-bold text-gray-900 mb-2">1. Overview</h2>
          <p>
            Afghan Recharge provides instant mobile top-up services for Afghan telecom networks.
            We are committed to protecting your privacy and being transparent about how we handle your data.
          </p>
        </div>

        <div>
          <h2 className="text-lg font-bold text-gray-900 mb-2">2. Information We Collect</h2>
          <ul className="list-disc list-inside space-y-1.5">
            <li><strong>Phone number:</strong> The recipient mobile number you enter to send a top-up.</li>
            <li><strong>Transaction details:</strong> Amount, operator, and recharge status for your order history.</li>
            <li><strong>Payment data:</strong> Processed securely by Stripe. We never see or store your card details.</li>
          </ul>
        </div>

        <div>
          <h2 className="text-lg font-bold text-gray-900 mb-2">3. How We Use Your Data</h2>
          <ul className="list-disc list-inside space-y-1.5">
            <li>To process and deliver your mobile top-up via DingConnect.</li>
            <li>To show your recharge history within the app.</li>
            <li>To provide customer support if you contact us.</li>
          </ul>
        </div>

        <div>
          <h2 className="text-lg font-bold text-gray-900 mb-2">4. Data Sharing</h2>
          <p>
            We share data only with our service providers to fulfill your order:
          </p>
          <ul className="list-disc list-inside space-y-1.5 mt-2">
            <li><strong>Stripe</strong> — processes your payment securely.</li>
            <li><strong>DingConnect</strong> — delivers the top-up to the recipient's phone.</li>
          </ul>
          <p className="mt-2">We do not sell or rent your personal data to any third party.</p>
        </div>

        <div>
          <h2 className="text-lg font-bold text-gray-900 mb-2">5. Data Storage</h2>
          <p>
            Transaction records are stored on secure servers (Supabase, EU region). Payment data is handled
            exclusively by Stripe and is never stored on our servers.
          </p>
        </div>

        <div>
          <h2 className="text-lg font-bold text-gray-900 mb-2">6. Your Rights</h2>
          <p>
            You may request access to, correction of, or deletion of your personal data by contacting us at
            afghantopup.support@gmail.com.
          </p>
        </div>

        <div>
          <h2 className="text-lg font-bold text-gray-900 mb-2">7. Contact</h2>
          <p>
            For any privacy questions, email us at afghantopup.support@gmail.com or message us on WhatsApp at +39 351 212 1290.
          </p>
        </div>
      </div>

      <div className="mt-8 p-4 rounded-xl bg-gray-50 border border-gray-100">
        <p className="text-xs text-gray-400 leading-relaxed">
          This privacy policy applies to the Afghan Recharge app (com.afghanrecharge.app) on Android and web.
        </p>
      </div>
    </section>
  );
}
