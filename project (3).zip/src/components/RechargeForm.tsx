import { useState, useCallback, useEffect } from 'react';
import { Zap, Loader2, ShieldCheck, RefreshCw, CreditCard } from 'lucide-react';
import { getOperator } from '@/lib/operators';
import { useI18n } from '@/lib/i18n';
import { supabase } from '@/lib/supabase';
import { OperatorLogo } from './OperatorLogos';
import { useExchangeRate } from '@/lib/exchangeRate';
import { getEurPriceForAmount, formatEur } from '@/lib/pricing';
import { getDingProducts, type DingProductOption } from '@/services/ding';

interface Props {
  operatorId: string;
  onHistoryChange: () => void;
}

const SERVICE_FEE = 5;

export function RechargeForm({ operatorId }: Props) {
  const { t } = useI18n();
  const operator = getOperator(operatorId)!;
  const rateState = useExchangeRate();
  const [phoneNumber, setPhoneNumber] = useState('');
  const [products, setProducts] = useState<DingProductOption[]>([]);
  const [productsLoading, setProductsLoading] = useState(true);
  const [amount, setAmount] = useState<number | null>(null);
  const [selectedSku, setSelectedSku] = useState('');
  const [error, setError] = useState('');
  const [redirecting, setRedirecting] = useState(false);
  const [redirectError, setRedirectError] = useState('');

  const finalAmount = amount;

  useEffect(() => {
    let active = true;
    setProductsLoading(true);
    setProducts([]);
    setAmount(null);
    setSelectedSku('');
    getDingProducts(operatorId)
      .then((liveProducts) => {
        if (active) setProducts(liveProducts);
      })
      .catch(() => {
        if (active) setError('Recharge options are temporarily unavailable. Please try again later.');
      })
      .finally(() => {
        if (active) setProductsLoading(false);
      });
    return () => { active = false; };
  }, [operatorId]);

  function normalizePhone(raw: string): string | null {
    const digits = raw.replace(/\D/g, '');
    if (digits.length === 9 && digits.startsWith('7')) {
      return '+93' + digits;
    }
    if (digits.length === 10 && digits.startsWith('07')) {
      return '+93' + digits.slice(1);
    }
    return null;
  }

  function isValidPhone(raw: string): boolean {
    return normalizePhone(raw) !== null;
  }

  const handlePhoneChange = useCallback((value: string) => {
    const digits = value.replace(/\D/g, '').slice(0, 10);
    setPhoneNumber(digits);
    if (error && isValidPhone(digits)) {
      setError('');
    }
  }, [error]);

  function validate(): boolean {
    const normalized = normalizePhone(phoneNumber);
    if (!normalized) {
      setError(t.invalidNumber);
      return false;
    }
    if (!finalAmount || finalAmount < 10 || !selectedSku) {
      setError(t.invalidAmount);
      return false;
    }
    setError('');
    return true;
  }

  async function handleProceed() {
    if (!validate()) return;
    setRedirecting(true);
    setRedirectError('');

    try {
      const { data, error: fnError } = await supabase.functions.invoke(
        'create-checkout-session',
        {
          body: {
            operator_id: operatorId,
            phone_number: normalizePhone(phoneNumber)!,
            amount_afn: finalAmount,
            sku_code: selectedSku,
            service_fee_afn: SERVICE_FEE,
          },
        },
      );

      if (fnError || !data) {
        throw new Error(fnError?.message || 'Failed to create checkout session');
      }

      if (data.checkout_url) {
        window.location.href = data.checkout_url;
      } else {
        throw new Error('No checkout URL returned');
      }
    } catch {
      setRedirecting(false);
      setRedirectError('Recharge is temporarily unavailable. Please try again later or contact support.');
    }
  }

  return (
    <section className="mt-6">
      {/* Operator banner */}
      <div
        className="flex items-center gap-3 p-4 rounded-2xl mb-5"
        style={{ backgroundColor: operator.colorLight }}
      >
        <div className="w-28 h-12 rounded-xl overflow-hidden shrink-0 bg-white/70 flex items-center justify-center px-1">
          <OperatorLogo operatorId={operatorId} className="w-full h-full" />
        </div>
        <div className="min-w-0">
          <p className="font-bold text-gray-900 break-words" style={{ overflowWrap: 'break-word' }}>
            {operator.name}
          </p>
          <p
            className="text-xs text-gray-600 break-words leading-snug"
            style={{ overflowWrap: 'break-word' }}
          >
            {t.networkDescription[operatorId]}
          </p>
        </div>
      </div>

      {/* Phone number input */}
      <div className="mb-5">
        <label className="block text-sm font-semibold text-gray-700 mb-1.5">{t.enterNumber}</label>
        <div className="flex items-stretch rounded-xl border-2 border-gray-200 bg-white overflow-hidden focus-within:border-afghan-red focus-within:ring-2 focus-within:ring-afghan-red/10 transition-all">
          <div className="flex items-center gap-1.5 px-3 bg-gray-50 border-e-2 border-gray-200 shrink-0">
            <span className="text-lg leading-none" aria-hidden="true">🇦🇫</span>
            <span className="font-semibold text-gray-700 text-base whitespace-nowrap" dir="ltr">+93</span>
          </div>
          <input
            type="tel"
            inputMode="numeric"
            value={phoneNumber}
            onChange={(e) => handlePhoneChange(e.target.value)}
            placeholder="7XX XXX XXX"
            className="flex-1 min-w-0 py-3 px-4 bg-white text-base text-gray-900 placeholder-gray-400 focus:outline-none border-0"
            maxLength={10}
            dir="ltr"
            disabled={redirecting}
          />
        </div>
      </div>

      {/* Amount selection */}
      <div className="mb-5">
        <div className="flex items-center justify-between mb-2">
          <label className="block text-sm font-semibold text-gray-700">{t.selectAmount}</label>
          {rateState.loading ? (
            <span className="flex items-center gap-1 text-xs text-gray-400">
              <Loader2 className="w-3 h-3 animate-spin" />
              {t.exchangeRateLoading}
            </span>
          ) : rateState.isFallback ? (
            <span className="flex items-center gap-1 text-xs text-amber-600">
              <RefreshCw className="w-3 h-3" onClick={rateState.refresh} style={{ cursor: 'pointer' }} />
              {t.exchangeRateError}
            </span>
          ) : (
            <span className="text-xs text-afghan-green font-medium" dir="ltr">
              1 EUR = {rateState.rate.toFixed(2)} AFN
            </span>
          )}
        </div>
        {productsLoading ? (
          <div className="flex items-center justify-center gap-2 rounded-2xl border-2 border-gray-100 bg-white py-8 text-sm text-gray-500">
            <Loader2 className="w-4 h-4 animate-spin" /> Loading live recharge options
          </div>
        ) : products.length ? (
          <div className="grid grid-cols-2 gap-3">
            {products.map((product) => {
              const isSelected = selectedSku === product.skuCode;
              const displayAmount = product.receiveCurrency === 'AFN' ? product.amount : product.amount * 70;
              return (
                <button
                  key={product.skuCode}
                  onClick={() => {
                    setAmount(displayAmount);
                    setSelectedSku(product.skuCode);
                    setError('');
                  }}
                  disabled={redirecting}
                  className={`flex flex-col items-center py-4 px-3 rounded-2xl border-2 transition-all ${
                    isSelected
                      ? 'border-afghan-red bg-afghan-red-light text-afghan-red shadow-md shadow-afghan-red/10'
                      : 'border-gray-200 bg-white text-gray-700 hover:border-gray-300 hover:shadow-sm'
                  } disabled:opacity-50 disabled:cursor-not-allowed`}
                >
                  <span className="text-2xl font-bold leading-none">{displayAmount}</span>
                  <span className="text-xs text-gray-500 mt-1">AFN</span>
                  <span className={`text-sm font-semibold mt-2 ${isSelected ? 'text-afghan-red' : 'text-gray-600'}`} dir="ltr">
                    {formatEur(product.sendValue * 1.1)}
                  </span>
                  <span className="text-xs text-gray-400">{t.eurPriceLabel}</span>
                </button>
              );
            })}
          </div>
        ) : (
          <p className="rounded-xl bg-amber-50 px-4 py-3 text-sm text-amber-700">No live recharge options are available right now.</p>
        )}
      </div>

      {error && (
        <p className="text-sm text-afghan-red mb-3 font-medium" role="alert">
          {error}
        </p>
      )}

      {redirectError && (
        <p className="text-sm text-afghan-red mb-3 font-medium" role="alert">
          {redirectError}
        </p>
      )}

      {/* Order summary */}
      {finalAmount && finalAmount >= 10 && (
        <div className="mb-5 p-4 rounded-xl bg-gray-50 space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-500">{t.amount}</span>
            <span className="font-semibold text-gray-900">{finalAmount} AFN</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-500">{t.serviceFee}</span>
            <span className="font-semibold text-gray-900">{SERVICE_FEE} AFN</span>
          </div>
          <div className="flex items-center justify-between pt-2 border-t border-gray-200">
            <span className="font-bold text-gray-900">{t.total}</span>
            <div className="text-end">
              <span className="font-bold text-lg text-afghan-red block">{formatEur(getEurPriceForAmount(finalAmount, rateState))}</span>
              <span className="text-xs text-gray-400" dir="ltr">
                EUR · incl. 10% margin
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Trust badge */}
      <div className="flex items-center justify-center gap-1.5 mb-4 text-xs text-afghan-green bg-afghan-green-light rounded-lg py-2 px-3">
        <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
        <span className="font-medium">{t.trustBadge}</span>
      </div>

      <button
        onClick={handleProceed}
        disabled={!phoneNumber || !finalAmount || !selectedSku || redirecting}
        className="w-full py-4 rounded-xl bg-gradient-to-r from-afghan-red to-afghan-red-dark text-white font-bold text-base shadow-lg shadow-afghan-red/20 hover:shadow-xl hover:shadow-afghan-red/30 transition-all disabled:opacity-40 disabled:cursor-not-allowed disabled:shadow-none flex items-center justify-center gap-2"
      >
        {redirecting ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" />
            {t.paymentProcessing}
          </>
        ) : (
          <>
            <CreditCard className="w-5 h-5" />
            {t.payNow} • {formatEur(getEurPriceForAmount(finalAmount || 0, rateState))}
          </>
        )}
      </button>
    </section>
  );
}
