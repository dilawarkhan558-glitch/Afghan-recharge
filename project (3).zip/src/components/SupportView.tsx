import { useState } from 'react';
import { LifeBuoy, Mail, ChevronDown, ChevronUp, HelpCircle, Headphones, Clock, MessageCircle, Zap } from 'lucide-react';
import { useI18n } from '@/lib/i18n';

const WHATSAPP_URL = 'https://wa.me/393512121290?text=' + encodeURIComponent('Salam, Afghan Topup help');
const EMAIL_URL = 'mailto:afghantopup.support@gmail.com';

export function SupportView() {
  const { t } = useI18n();
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  return (
    <section className="mt-6">
      <div className="flex items-center gap-2 mb-1">
        <LifeBuoy className="w-5 h-5 text-afghan-red" />
        <h2 className="text-lg font-bold text-gray-900">{t.support}</h2>
      </div>
      <p className="text-sm text-gray-500 mb-5">{t.supportDesc}</p>

      {/* Auto-message banner */}
      <div className="mb-5 p-4 rounded-2xl bg-gradient-to-r from-afghan-green-light to-emerald-50 border border-afghan-green/20 flex items-start gap-3">
        <div className="w-10 h-10 rounded-xl bg-afghan-green flex items-center justify-center shrink-0 shadow-sm">
          <Zap className="w-5 h-5 text-white" fill="currentColor" />
        </div>
        <p className="text-sm font-semibold text-afghan-green-dark leading-relaxed pt-1.5">
          {t.topupAutoMessage}
        </p>
      </div>

      {/* WhatsApp support button */}
      <a
        href={WHATSAPP_URL}
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center gap-3 p-4 rounded-2xl bg-gradient-to-r from-afghan-green to-afghan-green-dark shadow-lg shadow-afghan-green/20 hover:shadow-xl hover:shadow-afghan-green/30 transition-all mb-3"
      >
        <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
          <MessageCircle className="w-6 h-6 text-white" />
        </div>
        <div className="min-w-0 flex-1">
          <p className="font-bold text-white text-sm">{t.whatsappSupport}</p>
          <p className="text-xs text-white/80" dir="ltr">{t.whatsappNumber}</p>
        </div>
        <Headphones className="w-5 h-5 text-white/70 shrink-0" />
      </a>

      {/* Email support card */}
      <a
        href={EMAIL_URL}
        className="flex items-center gap-3 p-4 rounded-2xl border border-gray-100 bg-white shadow-sm hover:shadow-md hover:border-afghan-red/20 transition-all mb-5"
      >
        <div className="w-11 h-11 rounded-xl bg-afghan-red-light flex items-center justify-center shrink-0">
          <Mail className="w-5 h-5 text-afghan-red" />
        </div>
        <div className="min-w-0">
          <p className="font-semibold text-gray-900 text-sm">{t.emailSupport}</p>
          <p className="text-xs text-gray-500 break-all" dir="ltr">{t.emailAddress}</p>
        </div>
      </a>

      {/* Support hours */}
      <div className="flex items-center gap-3 p-4 rounded-2xl bg-amber-50 border border-amber-100 mb-6">
        <div className="w-11 h-11 rounded-xl bg-amber-100 flex items-center justify-center shrink-0">
          <Clock className="w-5 h-5 text-amber-600" />
        </div>
        <div className="min-w-0">
          <p className="font-semibold text-amber-900 text-sm">{t.supportHours}</p>
          <p className="text-xs text-amber-700" dir="ltr">{t.supportHoursValue}</p>
        </div>
      </div>

      {/* FAQ */}
      <div className="flex items-center gap-2 mb-3">
        <HelpCircle className="w-5 h-5 text-gray-400" />
        <h3 className="font-bold text-gray-900">{t.faqTitle}</h3>
      </div>

      <div className="space-y-2.5">
        {t.faqs.map((faq, idx) => {
          const isOpen = openFaq === idx;
          return (
            <div
              key={idx}
              className="rounded-2xl border border-gray-100 bg-white shadow-sm overflow-hidden transition-all"
            >
              <button
                onClick={() => setOpenFaq(isOpen ? null : idx)}
                className="w-full flex items-center justify-between gap-3 px-4 py-3.5 text-start hover:bg-gray-50 transition-colors"
              >
                <span className="font-semibold text-gray-900 text-sm break-words" style={{ overflowWrap: 'break-word' }}>
                  {faq.q}
                </span>
                {isOpen ? (
                  <ChevronUp className="w-4 h-4 text-gray-400 shrink-0" />
                ) : (
                  <ChevronDown className="w-4 h-4 text-gray-400 shrink-0" />
                )}
              </button>
              {isOpen && (
                <div className="px-4 pb-4 pt-0">
                  <p className="text-sm text-gray-600 leading-relaxed break-words" style={{ overflowWrap: 'break-word' }}>
                    {faq.a}
                  </p>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Contact description */}
      <div className="mt-6 p-4 rounded-2xl bg-afghan-red-light border border-afghan-red/10 text-center">
        <p className="text-sm font-semibold text-afghan-red-dark">{t.contactSupport}</p>
        <p className="text-xs text-afghan-red mt-1">{t.contactDesc}</p>
      </div>
    </section>
  );
}
