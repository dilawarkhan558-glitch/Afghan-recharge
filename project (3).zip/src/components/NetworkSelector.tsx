import { Check } from 'lucide-react';
import { OPERATORS } from '@/lib/operators';
import { useI18n } from '@/lib/i18n';
import { OperatorLogo } from './OperatorLogos';

interface Props {
  selected: string | null;
  onSelect: (id: string) => void;
}

export function NetworkSelector({ selected, onSelect }: Props) {
  const { t } = useI18n();

  return (
    <section className="mt-6">
      <div className="flex items-center gap-2 mb-1">
        <h2 className="text-lg font-bold text-gray-900">{t.selectNetwork}</h2>
      </div>
      <p className="text-sm text-gray-500 mb-4">{t.selectNetworkHint}</p>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {OPERATORS.map((op) => {
          const isSelected = selected === op.id;
          return (
            <button
              key={op.id}
              onClick={() => onSelect(op.id)}
              className={`relative flex flex-col items-center p-4 rounded-2xl border-2 transition-all duration-200 text-center group ${
                isSelected
                  ? 'border-afghan-red bg-afghan-red-light/50 shadow-md shadow-afghan-red/10 scale-[1.02]'
                  : 'border-gray-200 bg-white hover:border-gray-300 hover:shadow-sm'
              }`}
            >
              {isSelected && (
                <div className="absolute -top-2 -end-2 w-6 h-6 rounded-full bg-afghan-red flex items-center justify-center shadow-md">
                  <Check className="w-3.5 h-3.5 text-white" strokeWidth={3} />
                </div>
              )}

              <div
                className="w-full h-12 rounded-xl overflow-hidden mb-3 shrink-0 transition-transform group-hover:scale-105 flex items-center justify-center px-1"
                style={{ backgroundColor: op.colorLight }}
              >
                <OperatorLogo operatorId={op.id} className="w-full h-full" />
              </div>

              <span
                className="block text-sm font-semibold text-gray-900 leading-snug break-words w-full"
                style={{ wordBreak: 'break-word', overflowWrap: 'break-word' }}
              >
                {op.name}
              </span>
              <span
                className="block text-xs text-gray-500 leading-snug mt-0.5 break-words w-full line-clamp-3"
                style={{ wordBreak: 'break-word', overflowWrap: 'break-word' }}
              >
                {op.fullName}
              </span>
            </button>
          );
        })}
      </div>
    </section>
  );
}
