import { useState, useEffect, useCallback } from 'react';
import { Bell, CheckCircle2, Clock, AlertCircle, Gift } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { getOperator } from '@/lib/operators';
import { OperatorLogo } from './OperatorLogos';

interface RechargeRecord {
  id: string;
  operator_id: string;
  phone_number: string;
  amount_afn: number;
  status: string;
  topup_status: string | null;
  created_at: string;
}

interface NotificationItem {
  id: string;
  type: 'success' | 'pending' | 'failed';
  title: string;
  desc: string;
  time: string;
  operatorId?: string;
}

export function NotificationsView() {
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [loading, setLoading] = useState(true);

  const loadNotifications = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('recharges')
        .select('id, operator_id, phone_number, amount_afn, status, topup_status, created_at')
        .order('created_at', { ascending: false })
        .limit(20);

      if (error || !data) return;

      const items = (data as RechargeRecord[]).map((rec) => {
        const op = getOperator(rec.operator_id);
        const opName = op?.name || rec.operator_id;
        const time = new Date(rec.created_at).toLocaleString('en-GB', {
          day: '2-digit',
          month: 'short',
          hour: '2-digit',
          minute: '2-digit',
        });

        if (rec.status === 'completed') {
          return {
            id: rec.id,
            type: 'success' as const,
            title: `${rec.amount_afn} AFN delivered to ${opName}`,
            desc: `Top-up sent to ${rec.phone_number}`,
            time,
            operatorId: rec.operator_id,
          };
        } else if (rec.status === 'failed') {
          return {
            id: rec.id,
            type: 'failed' as const,
            title: `Top-up failed — ${rec.amount_afn} AFN`,
            desc: `Refund processing for ${rec.phone_number}`,
            time,
            operatorId: rec.operator_id,
          };
        } else {
          return {
            id: rec.id,
            type: 'pending' as const,
            title: `Processing ${rec.amount_afn} AFN for ${opName}`,
            desc: `Awaiting payment confirmation`,
            time,
            operatorId: rec.operator_id,
          };
        }
      });

      setNotifications(items);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadNotifications();
    const interval = setInterval(loadNotifications, 10000);
    return () => clearInterval(interval);
  }, [loadNotifications]);

  const iconMap = {
    success: <CheckCircle2 className="w-5 h-5 text-afghan-green" />,
    pending: <Clock className="w-5 h-5 text-amber-500" />,
    failed: <AlertCircle className="w-5 h-5 text-afghan-red" />,
  };

  const bgMap = {
    success: 'bg-afghan-green-light',
    pending: 'bg-amber-50',
    failed: 'bg-afghan-red-light',
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-3 border-gray-200 border-t-afghan-red rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <section className="mt-6">
      <div className="flex items-center gap-2 mb-1">
        <Bell className="w-5 h-5 text-afghan-red" />
        <h2 className="text-lg font-bold text-gray-900">Notifications</h2>
      </div>
      <p className="text-sm text-gray-500 mb-5">Updates about your recharges and deliveries</p>

      {/* Promo banner */}
      <div className="mb-5 p-4 rounded-2xl bg-gradient-to-r from-afghan-black to-gray-800 text-white flex items-center gap-3">
        <div className="w-11 h-11 rounded-xl bg-white/15 flex items-center justify-center shrink-0">
          <Gift className="w-5 h-5 text-white" />
        </div>
        <div>
          <p className="font-bold text-sm">Welcome to Afghan Recharge</p>
          <p className="text-xs text-white/70">Instant top-ups for all 5 Afghan networks</p>
        </div>
      </div>

      {notifications.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <div className="w-20 h-20 rounded-full bg-gray-100 flex items-center justify-center mb-4">
            <Bell className="w-10 h-10 text-gray-300" />
          </div>
          <h3 className="font-bold text-gray-900 text-lg mb-1">No notifications yet</h3>
          <p className="text-sm text-gray-500">Your recharge updates will appear here.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {notifications.map((n) => (
            <div
              key={n.id}
              className={`flex items-start gap-3 p-4 rounded-2xl ${bgMap[n.type]} border border-gray-100/50`}
            >
              <div className="shrink-0 mt-0.5">{iconMap[n.type]}</div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  {n.operatorId && (
                    <div className="w-16 h-7 rounded-md overflow-hidden shrink-0 flex items-center justify-center px-1 bg-white/60">
                      <OperatorLogo operatorId={n.operatorId} className="w-full h-full" />
                    </div>
                  )}
                  <p
                    className="font-semibold text-gray-900 text-sm break-words"
                    style={{ overflowWrap: 'break-word' }}
                  >
                    {n.title}
                  </p>
                </div>
                <p className="text-xs text-gray-500 mt-0.5">{n.desc}</p>
                <p className="text-xs text-gray-400 mt-1" dir="ltr">
                  {n.time}
                </p>
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
