import { supabase } from '@/lib/supabase';

export interface DingProductOption {
  skuCode: string;
  providerCode: string;
  name: string;
  minimum: number;
  maximum: number;
  amount: number;
  sendValue: number;
  sendCurrency: string;
  receiveCurrency: string;
}

export async function getDingProducts(operatorId: string): Promise<DingProductOption[]> {
  const { data, error } = await supabase.functions.invoke('ding-products', {
    body: { operator_id: operatorId },
  });

  if (error) throw new Error(error.message);
  if (!data || !Array.isArray(data.products)) throw new Error('Ding product list was unavailable');

  return data.products as DingProductOption[];
}
