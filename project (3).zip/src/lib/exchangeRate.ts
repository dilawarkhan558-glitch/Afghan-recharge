import { useState, useEffect, useCallback } from 'react';

// Fallback: 100 AFN = €1.80  →  1 EUR = 55.5556 AFN
export const FALLBACK_RATE_AFN_PER_EUR = 100 / 1.8;

const API_URL = 'https://open.er-api.com/v6/latest/EUR';
const CACHE_KEY = 'afghan_recharge_eur_afn_rate';
const CACHE_TTL_MS = 10 * 60 * 1000; // 10 minutes

interface CachedRate {
  rate: number;
  timestamp: number;
}

function loadCachedRate(): number | null {
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    if (!raw) return null;
    const cached = JSON.parse(raw) as CachedRate;
    if (Date.now() - cached.timestamp > CACHE_TTL_MS) return null;
    return cached.rate;
  } catch {
    return null;
  }
}

function saveCachedRate(rate: number) {
  try {
    const data: CachedRate = { rate, timestamp: Date.now() };
    localStorage.setItem(CACHE_KEY, JSON.stringify(data));
  } catch {
    // ignore
  }
}

async function fetchRate(): Promise<number> {
  const response = await fetch(API_URL);
  if (!response.ok) throw new Error(`Exchange API returned ${response.status}`);
  const data = await response.json();
  if (data?.result !== 'success' || !data?.rates?.AFN) {
    throw new Error('Exchange API returned unexpected data');
  }
  const rate = data.rates.AFN as number;
  if (!rate || rate <= 0) throw new Error('Invalid rate from API');
  return rate;
}

export interface ExchangeRateState {
  rate: number;
  loading: boolean;
  error: boolean;
  isFallback: boolean;
  refresh: () => void;
}

export function useExchangeRate(): ExchangeRateState {
  const [rate, setRate] = useState<number>(() => loadCachedRate() ?? FALLBACK_RATE_AFN_PER_EUR);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [isFallback, setIsFallback] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);

  const refresh = useCallback(() => setRefreshKey((k) => k + 1), []);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);

    fetchRate()
      .then((fetched) => {
        if (cancelled) return;
        setRate(fetched);
        setError(false);
        setIsFallback(false);
        saveCachedRate(fetched);
      })
      .catch(() => {
        if (cancelled) return;
        const cached = loadCachedRate();
        if (cached) {
          setRate(cached);
          setIsFallback(false);
        } else {
          setRate(FALLBACK_RATE_AFN_PER_EUR);
          setIsFallback(true);
        }
        setError(true);
      })
      .finally(() => {
        if (cancelled) return;
        setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [refreshKey]);

  return { rate, loading, error, isFallback, refresh };
}
