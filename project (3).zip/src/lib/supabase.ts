import { createClient, type SupabaseClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

let client: SupabaseClient;

try {
  client = createClient(
    supabaseUrl || 'https://placeholder.supabase.co',
    supabaseAnonKey || 'placeholder-anon-key',
  );
} catch (e) {
  console.error('Failed to initialize Supabase client:', e);
  client = createClient('https://placeholder.supabase.co', 'placeholder-anon-key');
}

export const supabase = client;

const dingKey = import.meta.env.VITE_DING_API_KEY as string | undefined;
if (dingKey && dingKey.length >= 4) {
  console.log(`[Ding] VITE_DING_API_KEY loaded — key starts with "${dingKey.slice(0, 4)}"`);
} else {
  console.warn('[Ding] VITE_DING_API_KEY not found in environment — DingConnect calls may fail with 401');
}
