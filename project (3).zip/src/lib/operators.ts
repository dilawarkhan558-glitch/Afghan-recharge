import type { OperatorInfo } from './i18n/types';

export const OPERATORS: OperatorInfo[] = [
  {
    id: 'roshan',
    name: 'Roshan',
    fullName: 'Roshan (Telecom Development Company Afghanistan)',
    color: '#E2231A',
    colorLight: '#FCE9E7',
    prefix: ['070', '074', '078', '079'],
  },
  {
    id: 'etisalat',
    name: 'Etisalat',
    fullName: 'Etisalat Afghanistan',
    color: '#7B9317',
    colorLight: '#F0F5DB',
    prefix: ['072', '073'],
  },
  {
    id: 'awcc',
    name: 'AWCC',
    fullName: 'Afghan Wireless Communication Company',
    color: '#004B8B',
    colorLight: '#DCEBF7',
    prefix: ['0700', '0701', '0702'],
  },
  {
    id: 'salaam',
    name: 'Salaam Telecom',
    fullName: 'Salaam Telecom (Afghanistan Telecom Regulatory Board)',
    color: '#00803F',
    colorLight: '#DFF0E6',
    prefix: ['0744', '0749', '0750'],
  },
  {
    id: 'mtn',
    name: 'MTN Afghanistan',
    fullName: 'MTN Afghanistan (Atoma)',
    color: '#FFCC00',
    colorLight: '#FFF9DC',
    prefix: ['077', '076'],
  },
];

export function getOperator(id: string): OperatorInfo | undefined {
  return OPERATORS.find((op) => op.id === id);
}

export const PRESET_AMOUNTS = [50, 100, 200, 300, 500, 1000];
