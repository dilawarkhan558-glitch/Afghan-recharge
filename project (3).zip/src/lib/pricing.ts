import type { ExchangeRateState } from './exchangeRate';

// Base cost in EUR per AFN denomination (what DingConnect charges us)
const BASE_COST_EUR: Record<number, number> = {
  100: 1.80,
  200: 3.60,
  500: 9.00,
  1000: 18.00,
};

export const PRICED_AMOUNTS = [100, 200, 500, 1000];

const PROFIT_MARGIN = 0.10; // 10% profit

export function calculateSellingPrice(baseCostEur: number): number {
  return Number((baseCostEur * (1 + PROFIT_MARGIN)).toFixed(2));
}

export function getBaseCostEur(afnAmount: number): number {
  return BASE_COST_EUR[afnAmount] ?? (afnAmount / 100) * 1.8;
}

export interface CardPrice {
  afnAmount: number;
  eurPrice: number;
  baseCostEur: number;
}

export function getCardPrices(_rateState: ExchangeRateState): CardPrice[] {
  return PRICED_AMOUNTS.map((afn) => {
    const baseCostEur = getBaseCostEur(afn);
    const eurPrice = calculateSellingPrice(baseCostEur);
    return { afnAmount: afn, eurPrice, baseCostEur };
  });
}

export function getEurPriceForAmount(afnAmount: number, _rateState: ExchangeRateState): number {
  const baseCostEur = getBaseCostEur(afnAmount);
  return calculateSellingPrice(baseCostEur);
}

export function formatEur(value: number): string {
  return new Intl.NumberFormat('en-DE', {
    style: 'currency',
    currency: 'EUR',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value);
}

export const PRICING_CONFIG = {
  netProfitMargin: PROFIT_MARGIN,
};
