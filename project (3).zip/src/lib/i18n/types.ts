export type Language = 'en' | 'ps' | 'fa';

export interface Translation {
  appName: string;
  tagline: string;
  trustBadge: string;
  // Nav
  navRecharge: string;
  navHistory: string;
  navSupport: string;
  // Network section
  selectNetwork: string;
  selectNetworkHint: string;
  networkDescription: Record<string, string>;
  // Recharge form
  enterNumber: string;
  phoneNumberPlaceholder: string;
  selectAmount: string;
  customAmount: string;
  proceedToPayment: string;
  invalidNumber: string;
  invalidAmount: string;
  exchangeRateLoading: string;
  exchangeRateError: string;
  perCard: string;
  eurPriceLabel: string;
  // Payment
  payment: string;
  paymentSummary: string;
  network: string;
  phoneNumber: string;
  amount: string;
  serviceFee: string;
  total: string;
  payNow: string;
  paymentProcessing: string;
  paymentSuccess: string;
  paymentSuccessDesc: string;
  paymentError: string;
  done: string;
  cancel: string;
  // Status view
  topupDelivering: string;
  backToRecharge: string;
  statusTimeout: string;
  // History
  history: string;
  historyEmpty: string;
  historyEmptyDesc: string;
  colDate: string;
  colNetwork: string;
  colNumber: string;
  colAmount: string;
  colStatus: string;
  statusCompleted: string;
  statusPending: string;
  statusFailed: string;
  // Support
  support: string;
  supportDesc: string;
  faqTitle: string;
  contactSupport: string;
  contactDesc: string;
  callUs: string;
  emailUs: string;
  whatsappSupport: string;
  whatsappNumber: string;
  emailSupport: string;
  emailAddress: string;
  supportHours: string;
  supportHoursValue: string;
  topupAutoMessage: string;
  faqs: { q: string; a: string }[];
  // Misc
  madeInBolt: string;
  poweredBy: string;
}

export interface OperatorInfo {
  id: string;
  name: string;
  fullName: string;
  color: string;
  colorLight: string;
  prefix: string[];
}
