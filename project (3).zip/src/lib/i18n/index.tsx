import { createContext, useContext, useState, useCallback, useEffect, type ReactNode } from 'react';
import type { Language, Translation } from './types';
import en from './en';
import ps from './ps';
import fa from './fa';

export const translations: Record<Language, Translation> = { en, ps, fa };

export const LANGUAGES: { code: Language; label: string; nativeLabel: string; flag: string; dir: 'ltr' | 'rtl' }[] = [
  { code: 'en', label: 'English', nativeLabel: 'English', flag: 'EN', dir: 'ltr' },
  { code: 'ps', label: 'Pashto', nativeLabel: 'پښتو', flag: 'PS', dir: 'rtl' },
  { code: 'fa', label: 'Dari', nativeLabel: 'دری', flag: 'FA', dir: 'rtl' },
];

interface I18nContextValue {
  lang: Language;
  t: Translation;
  dir: 'ltr' | 'rtl';
  setLang: (lang: Language) => void;
}

const I18nContext = createContext<I18nContextValue | null>(null);

const STORAGE_KEY = 'afghan_recharge_lang';

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Language>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY) as Language | null;
      if (stored && translations[stored]) return stored;
    } catch {
      // ignore
    }
    return 'en';
  });

  const dir = lang === 'en' ? 'ltr' : 'rtl';

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = dir;
  }, [lang, dir]);

  const setLang = useCallback((newLang: Language) => {
    setLangState(newLang);
    try {
      localStorage.setItem(STORAGE_KEY, newLang);
    } catch {
      // ignore
    }
  }, []);

  return (
    <I18nContext.Provider value={{ lang, t: translations[lang], dir, setLang }}>
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n(): I18nContextValue {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error('useI18n must be used within I18nProvider');
  return ctx;
}
