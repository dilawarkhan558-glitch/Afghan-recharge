import { useState, useEffect, Suspense, lazy } from 'react';
import { I18nProvider } from '@/lib/i18n';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import { DebugLogger } from '@/components/DebugLogger';
import { Header } from '@/components/Header';
import { NetworkSelector } from '@/components/NetworkSelector';
import { BottomNav, type Tab } from '@/components/BottomNav';

const RechargeForm = lazy(() =>
  import('@/components/RechargeForm').then((m) => ({ default: m.RechargeForm })),
);
const RechargeStatusView = lazy(() =>
  import('@/components/RechargeStatusView').then((m) => ({ default: m.RechargeStatusView })),
);
const HistoryView = lazy(() =>
  import('@/components/HistoryView').then((m) => ({ default: m.HistoryView })),
);
const NotificationsView = lazy(() =>
  import('@/components/NotificationsView').then((m) => ({ default: m.NotificationsView })),
);
const SettingsView = lazy(() =>
  import('@/components/SettingsView').then((m) => ({ default: m.SettingsView })),
);
const AdminView = lazy(() =>
  import('@/components/AdminView').then((m) => ({ default: m.AdminView })),
);
const PrivacyPolicyView = lazy(() =>
  import('@/components/PrivacyPolicyView').then((m) => ({ default: m.PrivacyPolicyView })),
);

function LazyFallback() {
  return (
    <div className="flex items-center justify-center py-20">
      <div className="w-8 h-8 border-3 border-gray-200 border-t-afghan-red rounded-full animate-spin" />
    </div>
  );
}

function AppContent() {
  const [tab, setTab] = useState<Tab>('recharge');
  const [selectedOperator, setSelectedOperator] = useState<string | null>(null);
  const [historyRefresh, setHistoryRefresh] = useState(0);
  const [rechargeFromUrl, setRechargeFromUrl] = useState<string | null>(null);
  const [showPrivacy, setShowPrivacy] = useState(false);

  useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const rechargeId = params.get('recharge_id');
      const status = params.get('status');
      if (rechargeId && (status === 'success' || status === 'cancelled')) {
        setRechargeFromUrl(rechargeId);
        window.history.replaceState({}, '', window.location.pathname);
      }
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [tab]);

  function handleHistoryChange() {
    setHistoryRefresh((v) => v + 1);
  }

  function clearRechargeFromUrl() {
    setRechargeFromUrl(null);
  }

  if (showPrivacy) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
        <DebugLogger />
        <Header />
        <main className="max-w-5xl mx-auto px-4 sm:px-6 pb-24 pt-4">
          <ErrorBoundary>
            <Suspense fallback={<LazyFallback />}>
              <PrivacyPolicyView onBack={() => setShowPrivacy(false)} />
            </Suspense>
          </ErrorBoundary>
        </main>
        <BottomNav active={tab} onChange={setTab} />
      </div>
    );
  }

  if (rechargeFromUrl) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
        <DebugLogger />
        <Header />
        <main className="max-w-5xl mx-auto px-4 sm:px-6 pb-24 pt-4">
          <ErrorBoundary>
            <Suspense fallback={<LazyFallback />}>
              <RechargeStatusView
                rechargeId={rechargeFromUrl}
                onDone={clearRechargeFromUrl}
                onHistoryChange={handleHistoryChange}
              />
            </Suspense>
          </ErrorBoundary>
        </main>
        <BottomNav active={tab} onChange={setTab} />
      </div>
    );
  }

  // Secret admin access: long-press the flag stripe in header triggers admin
  // For now, accessible via URL hash
  const showAdmin = typeof window !== 'undefined' && window.location.hash === '#admin';

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      <DebugLogger />
      <Header />

      <main className="max-w-5xl mx-auto px-4 sm:px-6 pb-24 pt-4">
        {showAdmin ? (
          <ErrorBoundary>
            <Suspense fallback={<LazyFallback />}>
              <AdminView onBack={() => { window.location.hash = ''; setTab('recharge'); }} />
            </Suspense>
          </ErrorBoundary>
        ) : (
          <>
            {tab === 'recharge' && (
              <>
                {!selectedOperator ? (
                  <ErrorBoundary>
                    <NetworkSelector selected={selectedOperator} onSelect={setSelectedOperator} />
                  </ErrorBoundary>
                ) : (
                  <>
                    <button
                      onClick={() => setSelectedOperator(null)}
                      className="text-sm font-medium text-afghan-red hover:text-afghan-red-dark mb-2 transition-colors"
                    >
                      ← Select Network
                    </button>
                    <ErrorBoundary>
                      <Suspense fallback={<LazyFallback />}>
                        <RechargeForm
                          operatorId={selectedOperator}
                          onHistoryChange={handleHistoryChange}
                        />
                      </Suspense>
                    </ErrorBoundary>
                  </>
                )}
              </>
            )}

            {tab === 'history' && (
              <ErrorBoundary>
                <Suspense fallback={<LazyFallback />}>
                  <HistoryView refreshKey={historyRefresh} />
                </Suspense>
              </ErrorBoundary>
            )}

            {tab === 'notifications' && (
              <ErrorBoundary>
                <Suspense fallback={<LazyFallback />}>
                  <NotificationsView />
                </Suspense>
              </ErrorBoundary>
            )}

            {tab === 'settings' && (
              <ErrorBoundary>
                <Suspense fallback={<LazyFallback />}>
                  <SettingsView onShowPrivacy={() => setShowPrivacy(true)} />
                </Suspense>
              </ErrorBoundary>
            )}
          </>
        )}
      </main>

      <BottomNav active={tab} onChange={setTab} />
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <I18nProvider>
        <AppContent />
      </I18nProvider>
    </ErrorBoundary>
  );
}
