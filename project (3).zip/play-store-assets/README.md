# Afghan Recharge — Play Store Assets

## App Details

- **App Name:** Afghan Recharge — Roshan, MTN, Etisalat
- **Package ID:** com.afghanrecharge.app
- **Category:** Finance
- **Content Rating:** Everyone
- **Target Audience:** Users sending mobile top-up to Afghan phone numbers

## Required Assets

### 1. App Icon (512x512)
Use `public/app-icon-512.webp` as the source. Convert to PNG for Play Console upload:
```
cp public/app-icon-512.webp play-store-assets/icon-512.png
```

### 2. Feature Graphic (1024x500)
Use `public/feature-graphic.webp`. Convert to PNG:
```
cp public/feature-graphic.webp play-store-assets/feature-graphic.png
```

### 3. Phone Screenshots (minimum 2, maximum 8)
Take screenshots at 1080x1920 or 1440x2560. Recommended screens:
1. **Network selector** — showing all 5 operator logos
2. **Recharge form** — amount buttons with EUR prices
3. **Payment confirmation** — order summary with total
4. **Recharge success** — completed status screen
5. **History** — list of past recharges
6. **Settings** — language selection

### 4. Store Listing Description

**Short Description (80 chars max):**
Instant top-up for Roshan, MTN, Etisalat, AWCC & Salaam — pay by card

**Full Description:**
Afghan Recharge lets you send instant mobile top-up to any Afghan phone number on Roshan, MTN, Etisalat, AWCC, or Salaam Telecom.

- Choose from live denominations fetched directly from the operator
- Pay securely with your credit/debit card via Stripe
- Top-up delivered automatically within seconds
- Full transaction history
- Available in English, Dari, and Pashto
- 24/7 support via WhatsApp and email

How it works:
1. Select the recipient's network
2. Choose a recharge amount
3. Enter the phone number
4. Pay with card
5. Top-up is delivered instantly

Your payment is processed by Stripe — we never store your card details. Top-ups are delivered via DingConnect, a global mobile top-up platform.

Privacy Policy: Available in-app under Settings > Privacy Policy.

## Signing the APK/AAB

### Generate a signed release build with Android Studio:

1. **Open the project in Android Studio:**
   ```
   Open > select the android/ folder
   ```

2. **Generate signed bundle:**
   - Menu: **Build > Generate Signed Bundle / APK**
   - Choose **Android App Bundle (.aab)** for Play Store
   - Create a new keystore (or use existing):
     - Key store path: `afghan-recharge.keystore`
     - Key alias: `afghan-recharge`
     - Set a strong password
     - Validity: 25+ years
     - Fill in your name/org details

3. **Configure signing in Gradle (optional but recommended for CI):**
   Add to `android/app/build.gradle`:
   ```groovy
   android {
       signingConfigs {
           release {
               storeFile file('afghan-recharge.keystore')
               storePassword 'YOUR_STORE_PASSWORD'
               keyAlias 'afghan-recharge'
               keyPassword 'YOUR_KEY_PASSWORD'
           }
       }
       buildTypes {
           release {
               signingConfig signingConfigs.release
               minifyEnabled true
               proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
           }
       }
   }
   ```

4. **Build from command line:**
   ```bash
   cd android
   ./gradlew bundleRelease
   # Output: android/app/build/outputs/bundle/release/app-release.aab
   ```

   Or for APK:
   ```bash
   ./gradlew assembleRelease
   # Output: android/app/build/outputs/apk/release/app-release.apk
   ```

5. **Upload to Play Store:**
   - Go to https://play.google.com/console
   - Create a new app with package name `com.afghanrecharge.app`
   - Upload the `.aab` file under Release > Production
   - Add the store listing text and screenshots from this file
   - Set up the privacy policy URL
   - Submit for review

### Important Notes
- Keep your keystore file safe — if you lose it, you cannot update the app
- Use the same keystore for all future updates
- AAB is required for new Play Store submissions (not APK)
- First review typically takes 1-3 business days
