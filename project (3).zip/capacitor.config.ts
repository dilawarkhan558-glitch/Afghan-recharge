import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.afghanrecharge.app',
  appName: 'AfghanRecharge',
  webDir: 'dist'
};

export default config;
