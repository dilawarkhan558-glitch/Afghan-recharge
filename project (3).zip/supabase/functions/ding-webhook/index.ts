import { createClient } from "jsr:@supabase/supabase-js@2";

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

const DING_API_BASE = Deno.env.get("DING_API_BASE") || "https://api.dingconnect.com/api/v1";

async function getSetting(key: string): Promise<string | null> {
  const { data } = await supabase.from("app_settings").select("value").eq("key", key).maybeSingle();
  return data?.value ?? null;
}

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey, X-Ding-Signature",
};

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", ...CORS },
  });
}

function errMsg(e: unknown): string {
  return e instanceof Error ? e.message : String(e);
}

/*
 * DingConnect delivery confirmation webhook.
 *
 * DingConnect calls this endpoint to report the final delivery status of a
 * top-up transfer. The payload includes the TransferRef (our transaction ID)
 * and a status that maps to SUCCESS or FAILED.
 *
 * DING_WEBHOOK_SECRET is read from the app_settings table (set via Admin panel)
 * or falls back to the DING_WEBHOOK_SECRET environment variable.
 */

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return json({ ok: true });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  try {
    // Read secrets from DB (set via Admin Settings panel)
    const dingWebhookSecret = await getSetting("DING_WEBHOOK_SECRET")
      || Deno.env.get("DING_WEBHOOK_SECRET")
      || "";

    if (dingWebhookSecret) {
      const sig = req.headers.get("x-ding-signature") || "";
      if (sig !== dingWebhookSecret) {
        return json({ error: "Invalid signature" }, 401);
      }
    }

    const body = await req.json();

    const transferRef = String(
      body.TransferRef || body.transferRef || body.transactionId || body.id || "",
    );
    const dingStatus = String(
      body.Status || body.status || body.DeliveryStatus || "",
    ).toUpperCase();

    if (!transferRef) {
      return json({ error: "Missing TransferRef in webhook payload" }, 400);
    }

    const { data: recharge, error: fetchError } = await supabase
      .from("recharges")
      .select("id, status, topup_status, payment_status, stripe_payment_intent_id")
      .eq("topup_transaction_id", transferRef)
      .maybeSingle();

    if (fetchError || !recharge) {
      return json({ error: "No recharge found for transfer ref" }, 404);
    }

    const successStatuses = ["SUCCESS", "SUCCESSFUL", "COMPLETED", "DELIVERED"];
    const failedStatuses = ["FAILED", "ERROR", "REJECTED", "CANCELLED"];

    if (successStatuses.includes(dingStatus)) {
      await supabase
        .from("recharges")
        .update({ status: "completed", topup_status: "success" })
        .eq("id", recharge.id);
    } else if (failedStatuses.includes(dingStatus)) {
      await supabase
        .from("recharges")
        .update({
          status: "failed",
          topup_status: "failed",
          topup_error: `Ding delivery failed: ${dingStatus}`,
        })
        .eq("id", recharge.id);

      if (recharge.payment_status === "paid" && recharge.stripe_payment_intent_id) {
        try {
          const stripe = new (await import("npm:stripe@14.25.0")).default(
            Deno.env.get("STRIPE_SECRET_KEY")!,
            { apiVersion: "2024-06-20" },
          );

          await supabase
            .from("recharges")
            .update({ refund_status: "pending" })
            .eq("id", recharge.id);

          const refund = await stripe.refunds.create({
            payment_intent: recharge.stripe_payment_intent_id,
          });

          await supabase
            .from("recharges")
            .update({
              refund_status: "succeeded",
              stripe_refund_id: refund.id,
              refund_amount_eur: parseFloat((refund.amount / 100).toFixed(2)),
            })
            .eq("id", recharge.id);
        } catch (refundErr) {
          await supabase
            .from("recharges")
            .update({
              refund_status: "failed",
              refund_error: errMsg(refundErr),
            })
            .eq("id", recharge.id);
        }
      }
    }

    return json({ received: true, transfer_ref: transferRef, status: dingStatus });
  } catch (err) {
    return json({ error: errMsg(err) }, 500);
  }
});
