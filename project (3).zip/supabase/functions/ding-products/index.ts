import { createClient } from "jsr:@supabase/supabase-js@2";

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const OPERATOR_TO_PROVIDER: Record<string, string> = {
  roshan: "RHAF",
  etisalat: "ETAF",
  awcc: "AWAF",
  salaam: "AQAF",
  mtn: "MTAF",
};

function json(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...CORS, "Content-Type": "application/json" },
  });
}

function numberValue(value: unknown): number {
  return typeof value === "number" ? value : Number.parseFloat(String(value));
}

function currency(value: unknown): string {
  return String(value || "").toUpperCase();
}

async function setting(key: string): Promise<string | null> {
  const { data } = await supabase.from("app_settings").select("value").eq("key", key).maybeSingle();
  return data?.value ?? null;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return json({ ok: true });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  try {
    const body = await req.json() as { operator_id?: string };
    const operatorId = String(body.operator_id || "").toLowerCase();
    const providerNeedle = OPERATOR_TO_PROVIDER[operatorId];
    if (!providerNeedle) return json({ error: "Unknown operator" }, 400);

    const apiKey = (await setting("DING_API_KEY")) || Deno.env.get("DING_API_KEY") || "";
    const apiBase = (await setting("DING_API_BASE")) || Deno.env.get("DING_API_BASE") || "https://api.dingconnect.com/api/v1";
    if (!apiKey) return json({ error: "DingConnect is not configured" }, 503);

    const response = await fetch(`${apiBase}/GetProducts?beneficiaryIsoCountryCode=AF`, {
      headers: { "Content-Type": "application/json", api_key: apiKey },
    });
    const raw = await response.text();
    if (!response.ok) throw new Error(`Ding API returned HTTP ${response.status}`);

    const data = JSON.parse(raw) as Record<string, unknown>;
    const products = (data.Items || data.items || data) as Array<Record<string, unknown>>;
    if (!Array.isArray(products)) throw new Error("Ding returned an invalid product list");

    const result = products.flatMap((product) => {
      const providerCode = String(product.ProviderCode || "").trim().toUpperCase();
      const regionCode = String(product.RegionCode || "").toUpperCase();
      const minimum = (product.Minimum || {}) as Record<string, unknown>;
      const maximum = (product.Maximum || {}) as Record<string, unknown>;
      if (regionCode !== "AF" || !providerCode.includes(providerNeedle)) return [];

      const min = numberValue(minimum.ReceiveValue);
      const max = numberValue(maximum.ReceiveValue);
      const sendValue = numberValue(maximum.SendValue);
      const receiveCurrency = currency(maximum.ReceiveCurrencyIso);
      const sendCurrency = currency(maximum.SendCurrencyIso);
      const amount = Number.isFinite(max) ? max : min;
      if (!Number.isFinite(amount) || !product.SkuCode || !Number.isFinite(sendValue)) return [];

      console.log(JSON.stringify({
        SkuCode: product.SkuCode,
        ProviderCode: providerCode,
        name: product.DefaultDisplayText || product.LocalizationKey || product.SkuCode,
        Minimum: min,
        Maximum: max,
        currency: receiveCurrency,
      }));

      return [{
        skuCode: String(product.SkuCode),
        providerCode,
        name: String(product.DefaultDisplayText || product.LocalizationKey || product.SkuCode),
        minimum: min,
        maximum: max,
        amount,
        sendValue,
        sendCurrency,
        receiveCurrency,
      }];
    });

    result.sort((a, b) => a.amount - b.amount);
    return json({ products: result });
  } catch (error) {
    return json({ error: error instanceof Error ? error.message : String(error) }, 500);
  }
});
