import { createClient } from "jsr:@supabase/supabase-js@2";
import Stripe from "npm:stripe@14.25.0";

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY")!, {
  apiVersion: "2024-06-20",
});

const DEFAULT_DING_API_BASE = "https://api.dingconnect.com/api/v1";
const AFN_PER_USD = 70;

async function getSetting(key: string): Promise<string | null> {
  const { data } = await supabase.from("app_settings").select("value").eq("key", key).maybeSingle();
  return data?.value ?? null;
}

async function getDingApiKey(): Promise<string> {
  return (await getSetting("DING_API_KEY")) || Deno.env.get("DING_API_KEY") || "";
}

async function getDingApiBase(): Promise<string> {
  return (await getSetting("DING_API_BASE")) || Deno.env.get("DING_API_BASE") || DEFAULT_DING_API_BASE;
}

// Pricing constants — must match src/lib/pricing.ts
const PROFIT_MARGIN = 0.10;

// Fallback base costs per AFN denomination (used when DingConnect lookup fails)
const FALLBACK_BASE_COST_EUR: Record<number, number> = {
  100: 1.80,
  200: 3.60,
  500: 9.00,
  1000: 18.00,
};

const OPERATOR_TO_DING_BRAND: Record<string, string> = {
  roshan: "Roshan",
  etisalat: "Etisalat",
  awcc: "Afghan Wireless",
  salaam: "Salaam",
  mtn: "MTN",
};

const OPERATOR_TO_PROVIDER_CODE: Record<string, string> = {
  roshan: "RHAF",
  etisalat: "ETAF",
  awcc: "AWAF",
  salaam: "AQAF",
  mtn: "MTAF",
};

interface DingProduct {
  BrandName?: string;
  ProviderCode?: string;
  ProductId?: string;
  SkuCode?: string;
  SendValue?: number | string;
  SendCurrencyIso?: string;
  ReceiveValue?: number | string;
  ReceiveCurrencyIso?: string;
  MinimumSend?: number | string;
  MaximumSend?: number | string;
  Minimum?: Record<string, unknown>;
  Maximum?: Record<string, unknown>;
  RegionCode?: string;
}

function productNumber(product: DingProduct, key: keyof DingProduct): number {
  const direct = product[key];
  const nested = key === "MinimumSend" ? product.Minimum : key === "MaximumSend" ? product.Maximum : product.Maximum;
  const nestedKey = key === "MinimumSend" ? "ReceiveValue" : key === "MaximumSend" ? "ReceiveValue" : key;
  const value = nested?.[nestedKey] ?? direct;
  return typeof value === "number" ? value : Number.parseFloat(String(value));
}

function productCurrency(product: DingProduct, key: "SendCurrencyIso" | "ReceiveCurrencyIso"): string {
  const nested = product.Maximum;
  return String(nested?.[key] || product[key] || "").toUpperCase();
}

function productProvider(product: DingProduct): string {
  return String(product.ProviderCode || product.BrandName || "").trim().toUpperCase();
}

function toProductUnits(amountAfn: number, currency: string): number {
  return currency === "USD" ? amountAfn / AFN_PER_USD : amountAfn;
}

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", ...CORS },
  });
}

function errMsg(e: unknown): string {
  return e instanceof Error ? e.message : String(e);
}

function calculateSellingPrice(baseCostEur: number): number {
  return Number((baseCostEur * (1 + PROFIT_MARGIN)).toFixed(2));
}

function getFallbackBaseCost(afnAmount: number): number {
  return FALLBACK_BASE_COST_EUR[afnAmount] ?? (afnAmount / 100) * 1.8;
}

async function dingFetch(apiBase: string, apiKey: string, path: string, options?: RequestInit): Promise<unknown> {
  const url = `${apiBase}${path}`;
  const maskedKey = apiKey.length > 8 ? apiKey.slice(0, 4) + "…" + apiKey.slice(-4) : "****";
  console.log(`[DingFetch] ${options?.method || "GET"} ${url} | header: api_key=${maskedKey}`);

  const response = await fetch(url, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      "api_key": apiKey,
      ...options?.headers,
    },
  });

  const rawText = await response.text().catch(() => "");

  if (response.status === 401 || response.status === 403) {
    console.error(`[DingFetch] AUTH FAILED ${response.status} | url=${url} | key=${maskedKey}`);
    console.error(`[DingFetch] Response body: "${rawText}"`);
    throw new Error(
      `API key invalid (HTTP ${response.status}). The DingConnect API rejected the api_key header. ` +
      `Response: ${rawText || response.statusText || "empty body"}`
    );
  }

  if (!response.ok) {
    let errorMsg = rawText || response.statusText || `HTTP ${response.status}`;
    if (rawText) {
      try {
        const parsed = JSON.parse(rawText);
        errorMsg = String(
          (parsed as Record<string, unknown>).error ||
          (parsed as Record<string, unknown>).Error ||
          (parsed as Record<string, unknown>).message ||
          rawText
        );
      } catch {
        // not JSON — use raw text
      }
    }
    console.error(`[DingFetch] FAILED ${response.status} | url=${url} | body="${rawText}"`);
    throw new Error(`Ding API ${path} failed (${response.status}): ${errorMsg}`);
  }

  if (!rawText || rawText.trim() === "") {
    console.error(`[DingFetch] EMPTY BODY | status=${response.status} | url=${url}`);
    throw new Error(
      `Ding API ${path} returned HTTP ${response.status} with empty body. ` +
      `Check the API base URL is correct.`
    );
  }

  try {
    return JSON.parse(rawText);
  } catch {
    console.error(`[DingFetch] JSON PARSE FAILED | url=${url} | body="${rawText}"`);
    throw new Error(
      `Ding API ${path} returned non-JSON response (HTTP ${response.status}): ${rawText.slice(0, 200)}`
    );
  }
}

async function getDingBaseCost(apiBase: string, apiKey: string, operatorId: string, afnAmount: number, skuCode?: string): Promise<number> {
  const brandName = OPERATOR_TO_DING_BRAND[operatorId];
  if (!brandName) return getFallbackBaseCost(afnAmount);

  try {
    const data = await dingFetch(
      apiBase,
      apiKey,
      `/GetProducts?beneficiaryIsoCountryCode=AF&brandName=${encodeURIComponent(brandName)}`,
    ) as Record<string, unknown>;
    const products = (data.Items || data.items || data) as DingProduct[];
    if (!Array.isArray(products)) return getFallbackBaseCost(afnAmount);

    for (const product of products) {
      console.log(JSON.stringify({
        skuCode: product.SkuCode || product.ProductId,
        providerCode: productProvider(product),
        minimum: productNumber(product, "MinimumSend"),
        maximum: productNumber(product, "MaximumSend"),
        sendCurrency: productCurrency(product, "SendCurrencyIso"),
        receiveCurrency: productCurrency(product, "ReceiveCurrencyIso"),
      }));
    }

    const providerCode = OPERATOR_TO_PROVIDER_CODE[operatorId] || brandName.replace(/[^a-z0-9]/gi, " ").trim().split(/\s+/)[0].toUpperCase();
    const candidates = products.filter((product) => {
      const provider = productProvider(product);
      return product.RegionCode === "AF" && provider === providerCode;
    });
    const selectedProduct = skuCode ? candidates.find((product) => product.SkuCode === skuCode) : null;
    if (selectedProduct && productNumber(selectedProduct, "SendValue") > 0) {
      return productNumber(selectedProduct, "SendValue");
    }

    const exactMatch = candidates.find(
      (p) => {
        const currency = productCurrency(p, "ReceiveCurrencyIso");
        return productNumber(p, "ReceiveValue") === toProductUnits(afnAmount, currency);
      },
    );
    if (exactMatch && productNumber(exactMatch, "SendValue") > 0 && productCurrency(exactMatch, "SendCurrencyIso") === "EUR") {
      return productNumber(exactMatch, "SendValue");
    }

    const flexible = candidates.find((p) => {
      const target = toProductUnits(afnAmount, productCurrency(p, "ReceiveCurrencyIso"));
      return Number.isFinite(productNumber(p, "MinimumSend")) &&
        Number.isFinite(productNumber(p, "MaximumSend")) &&
        target >= productNumber(p, "MinimumSend") &&
        target <= productNumber(p, "MaximumSend");
    });
    if (flexible && productNumber(flexible, "SendValue") > 0 && productCurrency(flexible, "SendCurrencyIso") === "EUR") {
      return productNumber(flexible, "SendValue");
    }

    const sorted = candidates
      .filter((p) => productNumber(p, "SendValue") > 0 && Number.isFinite(productNumber(p, "ReceiveValue")))
      .sort((a, b) =>
        Math.abs(productNumber(a, "ReceiveValue") - toProductUnits(afnAmount, productCurrency(a, "ReceiveCurrencyIso"))) -
        Math.abs(productNumber(b, "ReceiveValue") - toProductUnits(afnAmount, productCurrency(b, "ReceiveCurrencyIso")))
      );
    if (sorted[0] && productCurrency(sorted[0], "SendCurrencyIso") === "EUR") {
      return productNumber(sorted[0], "SendValue");
    }
  } catch (err) {
    console.error(`DingConnect product lookup failed, using fallback: ${errMsg(err)}`);
  }

  return getFallbackBaseCost(afnAmount);
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return json({ ok: true });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  try {
    const body = await req.json();
    const { operator_id, phone_number, amount_afn, sku_code, service_fee_afn } = body;

    if (!operator_id || !phone_number || !amount_afn) {
      return json({ error: "Missing required fields" }, 400);
    }

    const afnAmount = parseInt(String(amount_afn), 10);
    if (!afnAmount || afnAmount < 10) {
      return json({ error: "Invalid amount_afn" }, 400);
    }

    // 1. Determine base cost from DingConnect (with fallback)
    const dingApiKey = await getDingApiKey();
    if (!dingApiKey) {
      return json({ error: "DingConnect is not configured. Please contact support." }, 503);
    }

    const dingApiBase = await getDingApiBase();
    const baseCostEur = await getDingBaseCost(dingApiBase, dingApiKey, operator_id, afnAmount, String(sku_code || ''));

    // 2. Calculate the authoritative selling price
    const sellingPriceEur = calculateSellingPrice(baseCostEur);

    // 3. Create the recharge record
    const { data: recharge, error: dbError } = await supabase
      .from("recharges")
      .insert({
        operator_id,
        phone_number,
        amount_afn: afnAmount,
        service_fee_afn: service_fee_afn || 0,
        amount_eur: parseFloat(sellingPriceEur.toFixed(2)),
        base_cost_eur: parseFloat(baseCostEur.toFixed(2)),
        status: "pending",
        payment_status: "pending",
        topup_status: "pending",
      })
      .select()
      .single();

    if (dbError) throw dbError;

    // 4. Create Stripe Checkout Session
    const origin = req.headers.get("origin") || "https://afghanrecharge.app";
    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items: [
        {
          price_data: {
            currency: "eur",
            product_data: {
              name: `Mobile Recharge — ${afnAmount} AFN`,
              description: `Top-up for ${phone_number} (${operator_id})`,
            },
            unit_amount: Math.round(sellingPriceEur * 100),
          },
          quantity: 1,
        },
      ],
      metadata: {
        recharge_id: recharge.id,
        operator_id,
        phone_number,
        amount_afn: String(afnAmount),
        sku_code: String(sku_code || ''),
        service_fee_afn: String(service_fee_afn || 0),
        base_cost_eur: baseCostEur.toFixed(2),
        selling_price_eur: sellingPriceEur.toFixed(2),
      },
      success_url: `${origin}/?recharge_id=${recharge.id}&status=success`,
      cancel_url: `${origin}/?recharge_id=${recharge.id}&status=cancelled`,
    });

    // 5. Store the Stripe session ID
    await supabase
      .from("recharges")
      .update({ stripe_checkout_session_id: session.id })
      .eq("id", recharge.id);

    return json({
      checkout_url: session.url,
      recharge_id: recharge.id,
      session_id: session.id,
      selling_price_eur: parseFloat(sellingPriceEur.toFixed(2)),
      base_cost_eur: parseFloat(baseCostEur.toFixed(2)),
    });
  } catch (err) {
    return json({ error: errMsg(err) }, 500);
  }
});
