import { createClient } from "jsr:@supabase/supabase-js@2";

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

const DEFAULT_DING_API_BASE = "https://api.dingconnect.com/api/v1";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", ...CORS },
  });
}

function errMsg(e: unknown): string {
  return e instanceof Error ? e.message : String(e);
}

function maskValue(value: string): string {
  if (!value || value.length < 8) return value ? "••••" : "";
  return value.slice(0, 4) + "…" + value.slice(-4);
}

async function getSetting(key: string): Promise<string | null> {
  const { data } = await supabase
    .from("app_settings")
    .select("value")
    .eq("key", key)
    .maybeSingle();
  return data?.value ?? null;
}

async function getDingApiKey(): Promise<string> {
  const fromDb = await getSetting("DING_API_KEY");
  return fromDb || Deno.env.get("DING_API_KEY") || "";
}

async function getDingApiBase(): Promise<string> {
  const fromDb = await getSetting("DING_API_BASE");
  return fromDb || Deno.env.get("DING_API_BASE") || DEFAULT_DING_API_BASE;
}

async function dingFetch(apiBase: string, apiKey: string, path: string, options?: RequestInit): Promise<unknown> {
  const url = `${apiBase}${path}`;
  const maskedKey = apiKey.length > 8 ? apiKey.slice(0, 4) + "…" + apiKey.slice(-4) : "****";
  console.log(`[DingFetch] GET ${url} | header: api_key=${maskedKey}`);

  const response = await fetch(url, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      "api_key": apiKey,
      ...options?.headers,
    },
  });

  const rawText = await response.text().catch(() => "");

  if (response.status === 401 || response.status === 403) {
    console.error(`[DingFetch] AUTH FAILED ${response.status} | url=${url} | key=${maskedKey}`);
    console.error(`[DingFetch] Response body: "${rawText}"`);
    throw new Error(
      `API key invalid (HTTP ${response.status}). The DingConnect API rejected the api_key header. ` +
      `Response: ${rawText || response.statusText || "empty body"}`
    );
  }

  if (!response.ok) {
    let errorMsg = rawText || response.statusText || `HTTP ${response.status}`;
    if (rawText) {
      try {
        const parsed = JSON.parse(rawText);
        errorMsg = String(
          (parsed as Record<string, unknown>).error ||
          (parsed as Record<string, unknown>).Error ||
          (parsed as Record<string, unknown>).message ||
          rawText
        );
      } catch {
        // not JSON — use raw text
      }
    }
    console.error(`[DingFetch] FAILED ${response.status} | url=${url} | body="${rawText}"`);
    throw new Error(`Ding API ${path} failed (${response.status}): ${errorMsg}`);
  }

  if (!rawText || rawText.trim() === "") {
    console.error(`[DingFetch] EMPTY BODY | status=${response.status} | url=${url}`);
    throw new Error(
      `Ding API ${path} returned HTTP ${response.status} with empty body. ` +
      `Check the API base URL is correct.`
    );
  }

  try {
    return JSON.parse(rawText);
  } catch {
    console.error(`[DingFetch] JSON PARSE FAILED | url=${url} | body="${rawText}"`);
    throw new Error(
      `Ding API ${path} returned non-JSON response (HTTP ${response.status}): ${rawText.slice(0, 200)}`
    );
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return json({ ok: true });

  try {
    let action: string;
    let body: Record<string, unknown> = {};

    if (req.method === "POST") {
      body = await req.json();
      action = (body.action as string) || "balance";
    } else {
      const url = new URL(req.url);
      action = url.searchParams.get("action") || "balance";
    }

    // --- get_settings: returns masked values + config status ---
    if (action === "get_settings") {
      const dingApiKeyDb = await getSetting("DING_API_KEY");
      const dingApiKeyEnv = Deno.env.get("DING_API_KEY") || "";
      const dingWebhookSecret = await getSetting("DING_WEBHOOK_SECRET");
      const dingApiBaseDb = await getSetting("DING_API_BASE");
      const dingApiBaseEnv = Deno.env.get("DING_API_BASE") || "";

      const apiKey = dingApiKeyDb || dingApiKeyEnv;
      const apiBase = dingApiBaseDb || dingApiBaseEnv || DEFAULT_DING_API_BASE;

      return json({
        DING_API_KEY: {
          configured: !!apiKey,
          source: dingApiKeyDb ? "database" : dingApiKeyEnv ? "environment" : "none",
          masked: maskValue(apiKey),
        },
        DING_API_BASE: {
          configured: !!apiBase,
          source: dingApiBaseDb ? "database" : dingApiBaseEnv ? "environment" : "default",
          value: apiBase,
        },
        DING_WEBHOOK_SECRET: {
          configured: !!dingWebhookSecret,
          source: dingWebhookSecret ? "database" : "none",
          masked: maskValue(dingWebhookSecret || ""),
        },
      });
    }

    // --- save_settings: persists keys to app_settings (server-side only) ---
    if (action === "save_settings") {
      const settings = body.settings as Record<string, string>;

      if (!settings || typeof settings !== "object") {
        return json({ error: "settings object required" }, 400);
      }

      const allowedKeys = ["DING_API_KEY", "DING_WEBHOOK_SECRET", "DING_API_BASE"];
      const saved: string[] = [];
      const errors: string[] = [];

      for (const [key, value] of Object.entries(settings)) {
        if (!allowedKeys.includes(key)) continue;
        if (typeof value !== "string" || value.trim().length < 4) {
          errors.push(`${key}: value too short`);
          continue;
        }

        const { error } = await supabase
          .from("app_settings")
          .upsert({ key, value: value.trim(), updated_at: new Date().toISOString() });

        if (error) {
          errors.push(`${key}: ${error.message}`);
        } else {
          saved.push(key);
        }
      }

      return json({ saved, errors, ok: errors.length === 0 });
    }

    // --- test_connection: tests the Ding API with current/supplied credentials ---
    if (action === "test_connection") {
      const overrideKey = (body.api_key as string) || "";
      const overrideBase = (body.api_base as string) || "";

      const apiKey = overrideKey.trim() || await getDingApiKey();
      const apiBase = overrideBase.trim() || await getDingApiBase();

      if (!apiKey) {
        return json({ success: false, status: "no_key", message: "No API key configured. Save a key first." });
      }

      try {
        const data = await dingFetch(apiBase, apiKey, "/GetBalance") as Record<string, unknown>;
        const balance = data.Balance ?? data.balance ?? 0;
        const currency = data.CurrencyIso ?? data.currency ?? "EUR";

        return json({
          success: true,
          status: "connected",
          message: `Connected successfully. Balance: ${balance} ${currency}`,
          balance: Number(balance),
          currency: String(currency),
        });
      } catch (err) {
        const msg = errMsg(err);
        const isAuth = msg.includes("401") || msg.includes("403") || msg.includes("AuthenticationFailed");
        return json({
          success: false,
          status: isAuth ? "auth_failed" : "error",
          message: msg,
        });
      }
    }

    // --- list_products: diagnostic product catalog for one operator ---
    if (action === "list_products") {
      const brandName = String(body.brand_name || "MTN");
      const apiKey = await getDingApiKey();
      const apiBase = await getDingApiBase();
      if (!apiKey) return json({ error: "DingConnect is not configured" }, 503);

      const data = await dingFetch(
        apiBase,
        apiKey,
        `/GetProducts?beneficiaryIsoCountryCode=AF&brandName=${encodeURIComponent(brandName)}`,
      ) as Record<string, unknown>;
      const products = (data.Items || data.items || data) as Array<Record<string, unknown>>;
      const result = Array.isArray(products) ? products.map((product) => ({
        skuCode: product.SkuCode || product.ProductId || null,
        providerCode: product.ProviderCode || product.BrandName || null,
        minimum: (product.Minimum as Record<string, unknown> | undefined)?.ReceiveValue ?? product.MinimumSend ?? product.MinimumReceive ?? null,
        maximum: (product.Maximum as Record<string, unknown> | undefined)?.ReceiveValue ?? product.MaximumSend ?? product.MaximumReceive ?? null,
        sendValue: (product.Maximum as Record<string, unknown> | undefined)?.SendValue ?? product.SendValue ?? null,
        receiveValue: (product.Maximum as Record<string, unknown> | undefined)?.ReceiveValue ?? product.ReceiveValue ?? null,
        sendCurrency: (product.Maximum as Record<string, unknown> | undefined)?.SendCurrencyIso || product.SendCurrencyIso || null,
        receiveCurrency: (product.Maximum as Record<string, unknown> | undefined)?.ReceiveCurrencyIso || product.ReceiveCurrencyIso || null,
        regionCode: product.RegionCode || null,
      })) : [];

      return json({
        brand_name: brandName,
        count: result.length,
        fields: Array.isArray(products) && products[0] ? Object.keys(products[0]) : [],
        sample: Array.isArray(products) ? products.slice(0, 3) : [],
        products: result,
      });
    }

    // --- balance ---
    if (action === "balance") {
      const apiKey = await getDingApiKey();
      const apiBase = await getDingApiBase();
      if (!apiKey) {
        return json({ balance: null, error: "DING_API_KEY not configured — please add it in Settings" });
      }

      try {
        const data = await dingFetch(apiBase, apiKey, "/GetBalance") as Record<string, unknown>;
        const balance = data.Balance ?? data.balance ?? 0;
        const currency = data.CurrencyIso ?? data.currency ?? "EUR";

        return json({
          balance: Number(balance),
          currency: String(currency),
          raw: data,
        });
      } catch (err) {
        return json({
          balance: null,
          error: `Could not fetch Ding balance: ${errMsg(err)}`,
        });
      }
    }

    // --- stats ---
    if (action === "stats") {
      const { data: allRecharges, error } = await supabase
        .from("recharges")
        .select("status, topup_status, payment_status, refund_status, amount_eur, base_cost_eur, refund_amount_eur, created_at")
        .order("created_at", { ascending: false });

      if (error) return json({ error: error.message }, 500);

      const total = allRecharges?.length || 0;
      const completed = allRecharges?.filter((r) => r.status === "completed").length || 0;
      const failed = allRecharges?.filter((r) => r.status === "failed").length || 0;
      const pending = allRecharges?.filter((r) => r.status === "pending").length || 0;
      const refunded = allRecharges?.filter((r) => r.refund_status === "succeeded").length || 0;

      const totalRevenue = allRecharges
        ?.filter((r) => r.status === "completed")
        .reduce((sum, r) => sum + Number(r.amount_eur || 0), 0) || 0;

      const totalCost = allRecharges
        ?.filter((r) => r.status === "completed")
        .reduce((sum, r) => sum + Number(r.base_cost_eur || 0), 0) || 0;

      const totalRefunded = allRecharges
        ?.filter((r) => r.refund_status === "succeeded")
        .reduce((sum, r) => sum + Number(r.refund_amount_eur || 0), 0) || 0;

      return json({
        total,
        completed,
        failed,
        pending,
        refunded,
        total_revenue_eur: parseFloat(totalRevenue.toFixed(2)),
        total_cost_eur: parseFloat(totalCost.toFixed(2)),
        total_refunded_eur: parseFloat(totalRefunded.toFixed(2)),
        net_profit_eur: parseFloat((totalRevenue - totalCost).toFixed(2)),
      });
    }

    // --- recent ---
    if (action === "recent") {
      const limit = parseInt(String(body.limit || 20), 10);
      const { data: recent, error } = await supabase
        .from("recharges")
        .select("id, operator_id, phone_number, amount_afn, amount_eur, base_cost_eur, status, topup_status, payment_status, refund_status, topup_transaction_id, topup_error, created_at")
        .order("created_at", { ascending: false })
        .limit(limit);

      if (error) return json({ error: error.message }, 500);

      return json({ transactions: recent || [] });
    }

    return json({ error: "Unknown action" }, 400);
  } catch (err) {
    return json({ error: errMsg(err) }, 500);
  }
});
