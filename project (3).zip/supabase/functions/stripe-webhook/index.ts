import { createClient } from "jsr:@supabase/supabase-js@2";
import Stripe from "npm:stripe@14.25.0";

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
);

const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY")!, {
  apiVersion: "2024-06-20",
});

const DEFAULT_DING_API_BASE = "https://api.dingconnect.com/api/v1";
const AFN_PER_USD = 70;

async function getSetting(key: string): Promise<string | null> {
  const { data } = await supabase.from("app_settings").select("value").eq("key", key).maybeSingle();
  return data?.value ?? null;
}

async function getDingApiKey(): Promise<string> {
  return (await getSetting("DING_API_KEY")) || Deno.env.get("DING_API_KEY") || "";
}

async function getDingApiBase(): Promise<string> {
  return (await getSetting("DING_API_BASE")) || Deno.env.get("DING_API_BASE") || DEFAULT_DING_API_BASE;
}

const OPERATOR_TO_DING_BRAND: Record<string, string> = {
  roshan: "Roshan",
  etisalat: "Etisalat",
  awcc: "Afghan Wireless",
  salaam: "Salaam",
  mtn: "MTN",
};

const OPERATOR_TO_PROVIDER_CODE: Record<string, string> = {
  roshan: "RHAF",
  etisalat: "ETAF",
  awcc: "AWAF",
  salaam: "AQAF",
  mtn: "MTAF",
};

interface DingProduct {
  BrandName?: string;
  ProviderCode?: string;
  ProductId?: string;
  SkuCode?: string;
  SendValue?: number | string;
  SendCurrencyIso?: string;
  ReceiveValue?: number | string;
  ReceiveCurrencyIso?: string;
  MinimumSend?: number | string;
  MaximumSend?: number | string;
  Minimum?: Record<string, unknown>;
  Maximum?: Record<string, unknown>;
  RegionCode?: string;
}

function productNumber(product: DingProduct, key: keyof DingProduct): number {
  const direct = product[key];
  const nested = key === "MinimumSend" ? product.Minimum : key === "MaximumSend" ? product.Maximum : product.Maximum;
  const nestedKey = key === "MinimumSend" ? "ReceiveValue" : key === "MaximumSend" ? "ReceiveValue" : key;
  const value = nested?.[nestedKey] ?? direct;
  return typeof value === "number" ? value : Number.parseFloat(String(value));
}

function productCurrency(product: DingProduct, key: "SendCurrencyIso" | "ReceiveCurrencyIso"): string {
  const nested = product.Maximum;
  return String(nested?.[key] || product[key] || "").toUpperCase();
}

function productProvider(product: DingProduct): string {
  return String(product.ProviderCode || product.BrandName || "").trim().toUpperCase();
}

function toProductUnits(amountAfn: number, currency: string): number {
  return currency === "USD" ? amountAfn / AFN_PER_USD : amountAfn;
}

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", ...CORS },
  });
}

function errMsg(e: unknown): string {
  return e instanceof Error ? e.message : String(e);
}

async function dingFetch(apiBase: string, apiKey: string, path: string, options?: RequestInit): Promise<unknown> {
  const url = `${apiBase}${path}`;
  const maskedKey = apiKey.length > 8 ? apiKey.slice(0, 4) + "…" + apiKey.slice(-4) : "****";
  console.log(`[DingFetch] ${options?.method || "GET"} ${url} | header: api_key=${maskedKey}`);

  const response = await fetch(url, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      "api_key": apiKey,
      ...options?.headers,
    },
  });

  const rawText = await response.text().catch(() => "");

  if (response.status === 401 || response.status === 403) {
    console.error(`[DingFetch] AUTH FAILED ${response.status} | url=${url} | key=${maskedKey}`);
    console.error(`[DingFetch] Response body: "${rawText}"`);
    throw new Error(
      `API key invalid (HTTP ${response.status}). The DingConnect API rejected the api_key header. ` +
      `Response: ${rawText || response.statusText || "empty body"}`
    );
  }

  if (!response.ok) {
    let errorMsg = rawText || response.statusText || `HTTP ${response.status}`;
    if (rawText) {
      try {
        const parsed = JSON.parse(rawText);
        errorMsg = String(
          (parsed as Record<string, unknown>).error ||
          (parsed as Record<string, unknown>).Error ||
          (parsed as Record<string, unknown>).message ||
          rawText
        );
      } catch {
        // not JSON — use raw text
      }
    }
    console.error(`[DingFetch] FAILED ${response.status} | url=${url} | body="${rawText}"`);
    throw new Error(`Ding API ${path} failed (${response.status}): ${errorMsg}`);
  }

  if (!rawText || rawText.trim() === "") {
    console.error(`[DingFetch] EMPTY BODY | status=${response.status} | url=${url}`);
    throw new Error(
      `Ding API ${path} returned HTTP ${response.status} with empty body. ` +
      `Check the API base URL is correct.`
    );
  }

  try {
    return JSON.parse(rawText);
  } catch {
    console.error(`[DingFetch] JSON PARSE FAILED | url=${url} | body="${rawText}"`);
    throw new Error(
      `Ding API ${path} returned non-JSON response (HTTP ${response.status}): ${rawText.slice(0, 200)}`
    );
  }
}

async function getProductsForOperator(apiBase: string, apiKey: string, brandName: string): Promise<DingProduct[]> {
  const data = await dingFetch(
    apiBase,
    apiKey,
    `/GetProducts?beneficiaryIsoCountryCode=AF&brandName=${encodeURIComponent(brandName)}`,
  ) as Record<string, unknown>;
  const products = (data.Items || data.items || data) as DingProduct[];
  if (!Array.isArray(products)) return [];

  for (const product of products) {
    console.log(JSON.stringify({
      skuCode: product.SkuCode || product.ProductId,
      providerCode: productProvider(product),
      minimum: product.MinimumSend,
      maximum: product.MaximumSend,
      sendCurrency: productCurrency(product, "SendCurrencyIso"),
      receiveCurrency: productCurrency(product, "ReceiveCurrencyIso"),
    }));
  }

  return products;
}

function findProductForAmount(products: DingProduct[], targetAfn: number, providerCode: string, skuCode?: string): DingProduct | null {
  const candidates = products.filter((product) => {
    const provider = productProvider(product);
    return product.RegionCode === "AF" && (!provider || provider === providerCode);
  });
  const scopedProducts = candidates;
  const selectedProduct = skuCode ? scopedProducts.find((product) => product.SkuCode === skuCode) : null;
  if (selectedProduct) return selectedProduct;

  const exactMatch = scopedProducts.find((p) =>
    productNumber(p, "ReceiveValue") === toProductUnits(targetAfn, productCurrency(p, "ReceiveCurrencyIso")),
  );
  if (exactMatch) return exactMatch;

  const flexible = scopedProducts.find((p) => {
    const target = toProductUnits(targetAfn, productCurrency(p, "ReceiveCurrencyIso"));
    return Number.isFinite(productNumber(p, "MinimumSend")) &&
      Number.isFinite(productNumber(p, "MaximumSend")) &&
      target >= productNumber(p, "MinimumSend") &&
      target <= productNumber(p, "MaximumSend");
  });
  if (flexible) return flexible;

  const sorted = scopedProducts
    .filter((p) => productNumber(p, "ReceiveValue") > 0)
    .sort((a, b) =>
      Math.abs(productNumber(a, "ReceiveValue") - toProductUnits(targetAfn, productCurrency(a, "ReceiveCurrencyIso"))) -
      Math.abs(productNumber(b, "ReceiveValue") - toProductUnits(targetAfn, productCurrency(b, "ReceiveCurrencyIso")))
    );
  return sorted[0] || null;
}

async function sendTransfer(
  apiBase: string,
  apiKey: string,
  product: DingProduct,
  phoneNumber: string,
): Promise<{ transactionId: string; sendValue: number; receiveValue: number }> {
  const accountNumber = phoneNumber.replace("+", "");
  const skuCode = product.SkuCode || product.ProductId || "";
  const distributorRef = `AFG-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
  const sendValue = productNumber(product, "SendValue");
  const sendCurrency = productCurrency(product, "SendCurrencyIso");

  const body: Record<string, unknown> = {
    DistributorRef: distributorRef,
    SkuCode: skuCode,
    AccountNumber: accountNumber,
    SendValue: sendValue,
    SendCurrencyIso: sendCurrency,
    ValidateOnly: false,
  };

  console.log(`[SendTransfer] DistributorRef=${distributorRef} SkuCode=${skuCode} AccountNumber=${accountNumber} SendValue=${sendValue} ${sendCurrency}`);

  const data = await dingFetch(apiBase, apiKey, "/SendTransfer", {
    method: "POST",
    body: JSON.stringify(body),
  }) as Record<string, unknown>;

  return {
    transactionId: String(
      data.TransferRef || data.transferRef || data.transactionId || data.id || distributorRef,
    ),
    sendValue: Number(data.SendValue || sendValue),
    receiveValue: Number(data.ReceiveValue || productNumber(product, "ReceiveValue")),
  };
}

async function deliverTopup(
  apiBase: string,
  apiKey: string,
  phoneNumber: string,
  operatorId: string,
  amountAfn: number,
  skuCode?: string,
): Promise<{ success: boolean; transaction_id?: string; error?: string }> {
  try {
    if (!apiKey) {
      return { success: false, error: "Ding API key not configured — add it in the Admin Settings panel" };
    }

    const brandName = OPERATOR_TO_DING_BRAND[operatorId];
    if (!brandName) {
      return { success: false, error: `No Ding brand mapping for operator: ${operatorId}` };
    }

    const products = await getProductsForOperator(apiBase, apiKey, brandName);
    if (!products.length) {
      return { success: false, error: `No Ding products found for ${brandName} in Afghanistan` };
    }

    const providerCode = OPERATOR_TO_PROVIDER_CODE[operatorId] || brandName.replace(/[^a-z0-9]/gi, " ").trim().split(/\s+/)[0].toUpperCase();
    const product = findProductForAmount(products, amountAfn, providerCode, skuCode);
    if (!product) {
      return { success: false, error: `No suitable Ding product found for ${amountAfn} AFN on ${brandName}` };
    }

    const result = await sendTransfer(apiBase, apiKey, product, phoneNumber);
    return { success: true, transaction_id: result.transactionId };
  } catch (err) {
    return { success: false, error: errMsg(err) };
  }
}

async function autoRefund(rechargeId: string, paymentIntentId: string): Promise<void> {
  try {
    await supabase
      .from("recharges")
      .update({ refund_status: "pending" })
      .eq("id", rechargeId);

    const refund = await stripe.refunds.create({
      payment_intent: paymentIntentId,
    });

    await supabase
      .from("recharges")
      .update({
        refund_status: "succeeded",
        stripe_refund_id: refund.id,
        refund_amount_eur: parseFloat((refund.amount / 100).toFixed(2)),
      })
      .eq("id", rechargeId);
  } catch (err) {
    await supabase
      .from("recharges")
      .update({
        refund_status: "failed",
        refund_error: errMsg(err),
      })
      .eq("id", rechargeId);
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return json({ ok: true });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  try {
    const rawBody = await req.text();
    let event: Stripe.Event;

    const sig = req.headers.get("stripe-signature");
    const webhookSecret = Deno.env.get("STRIPE_WEBHOOK_SECRET");

    if (webhookSecret && sig) {
      try {
        event = await stripe.webhooks.constructEventAsync(rawBody, sig, webhookSecret);
      } catch (err) {
        return json({ error: `Webhook signature verification failed: ${errMsg(err)}` }, 400);
      }
    } else {
      event = JSON.parse(rawBody) as Stripe.Event;
    }

    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;
        const rechargeId = session.metadata?.recharge_id;
        const operatorId = session.metadata?.operator_id;
        const phoneNumber = session.metadata?.phone_number;
        const amountAfn = parseInt(session.metadata?.amount_afn || "0", 10);
        const skuCode = session.metadata?.sku_code || "";

        if (!rechargeId || !operatorId || !phoneNumber || !amountAfn) {
          return json({ error: "Missing recharge metadata in session" }, 400);
        }

        const paymentIntentId = session.payment_intent as string;

        // Mark payment as paid
        await supabase
          .from("recharges")
          .update({
            payment_status: "paid",
            stripe_payment_intent_id: paymentIntentId || null,
            topup_status: "processing",
          })
          .eq("id", rechargeId);

        // Auto-deliver the top-up via DingConnect
        const dingApiKey = await getDingApiKey();
        const dingApiBase = await getDingApiBase();
        const result = await deliverTopup(dingApiBase, dingApiKey, phoneNumber, operatorId, amountAfn, skuCode);

        if (result.success) {
          await supabase
            .from("recharges")
            .update({
              status: "completed",
              topup_status: "success",
              topup_transaction_id: result.transaction_id || null,
            })
            .eq("id", rechargeId);
        } else {
          // Top-up failed — auto-refund the customer via Stripe
          await supabase
            .from("recharges")
            .update({
              status: "failed",
              topup_status: "failed",
              topup_error: result.error || "Unknown error",
            })
            .eq("id", rechargeId);

          if (paymentIntentId) {
            await autoRefund(rechargeId, paymentIntentId);
          }
        }

        return json({ received: true, topup_success: result.success });
      }

      case "checkout.session.expired": {
        const session = event.data.object as Stripe.Checkout.Session;
        const rechargeId = session.metadata?.recharge_id;
        if (rechargeId) {
          await supabase
            .from("recharges")
            .update({
              payment_status: "failed",
              status: "failed",
              topup_status: "skipped",
              topup_error: "Checkout session expired",
            })
            .eq("id", rechargeId);
        }
        return json({ received: true });
      }

      default:
        return json({ received: true, type: event.type });
    }
  } catch (err) {
    return json({ error: errMsg(err) }, 500);
  }
});
