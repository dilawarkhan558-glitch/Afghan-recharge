-- Remove Stripe-related columns from recharges table
ALTER TABLE recharges DROP COLUMN IF EXISTS stripe_session_id;
ALTER TABLE recharges DROP COLUMN IF EXISTS stripe_payment_intent_id;

-- Remove EUR exchange rate columns (DingConnect handles pricing in AFN directly)
ALTER TABLE recharges DROP COLUMN IF EXISTS eur_amount;
ALTER TABLE recharges DROP COLUMN IF EXISTS exchange_rate;

-- Update status constraint: remove 'processing', add 'delivered'
ALTER TABLE recharges DROP CONSTRAINT IF EXISTS recharges_status_check;
ALTER TABLE recharges ADD CONSTRAINT recharges_status_check
  CHECK (status IN ('completed', 'pending', 'failed'));

-- Update topup_status constraint to include 'delivered'
ALTER TABLE recharges DROP CONSTRAINT IF EXISTS recharges_topup_status_check;
ALTER TABLE recharges ADD CONSTRAINT recharges_topup_status_check
  CHECK (topup_status IN ('pending', 'processing', 'success', 'failed', 'skipped'));