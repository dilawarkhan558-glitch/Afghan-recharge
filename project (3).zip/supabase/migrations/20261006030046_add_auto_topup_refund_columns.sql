/*
# Add auto-refund tracking columns for AUTO TOPUP mode

## Purpose
When a DingConnect top-up fails after Stripe payment succeeds, the system
automatically issues a Stripe refund. These columns track that refund so the
admin panel and customer history can show the full lifecycle.

## New Columns on `recharges`
1. `refund_status` (text, default 'none') — tracks the refund state:
   - 'none'     = no refund needed or attempted
   - 'pending'  = refund has been initiated
   - 'succeeded' = refund completed successfully
   - 'failed'   = refund attempt failed
2. `stripe_refund_id` (text, nullable) — Stripe refund ID (re_XXXX) for audit
3. `refund_amount_eur` (numeric, nullable) — amount refunded in EUR
4. `refund_error` (text, nullable) — error message if refund failed

## Security
- No new tables. No RLS policy changes.
- The recharges table already has RLS enabled with anon/authenticated CRUD policies.
*/

ALTER TABLE recharges
  ADD COLUMN IF NOT EXISTS refund_status text NOT NULL DEFAULT 'none',
  ADD COLUMN IF NOT EXISTS stripe_refund_id text,
  ADD COLUMN IF NOT EXISTS refund_amount_eur numeric,
  ADD COLUMN IF NOT EXISTS refund_error text;
