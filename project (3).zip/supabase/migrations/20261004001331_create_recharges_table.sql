/*
# Create recharges table (single-tenant, no auth)

1. New Tables
- `recharges`
  - `id` (uuid, primary key)
  - `operator_id` (text, not null) — which telecom operator
  - `phone_number` (text, not null) — the number being recharged
  - `amount_afn` (integer, not null) — recharge amount in Afghan Afghani
  - `service_fee_afn` (integer, not null, default 0) — service fee
  - `status` (text, not null, default 'completed') — completed | pending | failed
  - `created_at` (timestamptz, default now())

2. Security
- Enable RLS on `recharges`.
- Allow anon + authenticated CRUD because this is a no-auth single-tenant app
  with intentionally shared/public data.
*/

CREATE TABLE IF NOT EXISTS recharges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  operator_id text NOT NULL,
  phone_number text NOT NULL,
  amount_afn integer NOT NULL CHECK (amount_afn > 0),
  service_fee_afn integer NOT NULL DEFAULT 0 CHECK (service_fee_afn >= 0),
  status text NOT NULL DEFAULT 'completed' CHECK (status IN ('completed', 'pending', 'failed')),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE recharges ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_recharges" ON recharges;
CREATE POLICY "anon_select_recharges" ON recharges FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_recharges" ON recharges;
CREATE POLICY "anon_insert_recharges" ON recharges FOR INSERT
TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_recharges" ON recharges;
CREATE POLICY "anon_update_recharges" ON recharges FOR UPDATE
TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_recharges" ON recharges;
CREATE POLICY "anon_delete_recharges" ON recharges FOR DELETE
TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_recharges_created_at ON recharges (created_at DESC);
