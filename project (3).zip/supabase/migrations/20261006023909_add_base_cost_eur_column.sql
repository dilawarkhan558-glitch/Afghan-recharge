/*
# Add base_cost_eur column to recharges table

1. Changes
- Add `base_cost_eur` column (numeric, nullable) to `recharges`.
  Stores the DingConnect base cost in EUR for each recharge, so we can
  track profit margins on completed transactions.
- No data loss: existing rows get NULL for the new column.
2. Security
- No RLS policy changes. Column inherits existing table-level policies.
*/

ALTER TABLE recharges
ADD COLUMN IF NOT EXISTS base_cost_eur numeric;
