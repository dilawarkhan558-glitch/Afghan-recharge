/*
# Create app_settings table

## Purpose
Stores sensitive configuration values (API keys, webhook secrets) that the
admin enters through the UI. These values are saved server-side and can only
be read by edge functions using the service role key — they are NEVER exposed
to the browser or client JavaScript.

## New Tables
- `app_settings`
  - `key`        (text, primary key) — setting name, e.g. "DING_API_KEY"
  - `value`      (text, not null)    — the secret value
  - `updated_at` (timestamptz)       — when it was last saved

## Security
- RLS is enabled with NO policies, meaning no client (anon or authenticated)
  can read, write, or even see that this table exists via the browser.
- Edge functions use the service role key which bypasses RLS entirely, giving
  them full read/write access — this is the ONLY way to access this table.
*/

CREATE TABLE IF NOT EXISTS app_settings (
  key        text PRIMARY KEY,
  value      text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE app_settings ENABLE ROW LEVEL SECURITY;
-- No policies: table is fully inaccessible from the browser (anon/authenticated).
-- Only the service role key (used exclusively by edge functions) can read/write it.
