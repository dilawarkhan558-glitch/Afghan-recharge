-- Add Ding top-up tracking columns to recharges table
ALTER TABLE recharges
  ADD COLUMN IF NOT EXISTS topup_status text DEFAULT 'pending' CHECK (topup_status IN ('pending', 'processing', 'success', 'failed', 'skipped')),
  ADD COLUMN IF NOT EXISTS topup_transaction_id text,
  ADD COLUMN IF NOT EXISTS topup_error text;

-- Add 'processing' to status constraint
ALTER TABLE recharges DROP CONSTRAINT IF EXISTS recharges_status_check;
ALTER TABLE recharges ADD CONSTRAINT recharges_status_check
  CHECK (status IN ('completed', 'pending', 'failed', 'processing'));