/*
# Add Stripe payment columns to recharges table

## Purpose
Supports the Stripe Checkout payment flow: customer pays via Stripe, then DingConnect top-up is triggered.
Previously the app went straight to DingConnect without payment. Now we need to track the Stripe payment
separately from the DingConnect top-up delivery.

## Changes
1. New columns on `recharges`:
   - `stripe_checkout_session_id` (text, nullable) — Stripe Checkout Session ID
   - `stripe_payment_intent_id` (text, nullable) — Stripe Payment Intent ID
   - `payment_status` (text, nullable, default 'pending') — Tracks Stripe payment state: pending, paid, failed
   - `amount_eur` (numeric(10,2), nullable) — The EUR amount charged via Stripe (for audit/reconciliation)

2. Check constraint on `payment_status` to enforce valid values.

## Security
- No RLS policy changes. Existing anon/authenticated policies remain intact.
- No destructive operations — all additions are additive with IF NOT EXISTS guards.
*/

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
    WHERE table_name = 'recharges' AND column_name = 'stripe_checkout_session_id') THEN
    ALTER TABLE recharges ADD COLUMN stripe_checkout_session_id text;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
    WHERE table_name = 'recharges' AND column_name = 'stripe_payment_intent_id') THEN
    ALTER TABLE recharges ADD COLUMN stripe_payment_intent_id text;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
    WHERE table_name = 'recharges' AND column_name = 'payment_status') THEN
    ALTER TABLE recharges ADD COLUMN payment_status text DEFAULT 'pending';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
    WHERE table_name = 'recharges' AND column_name = 'amount_eur') THEN
    ALTER TABLE recharges ADD COLUMN amount_eur numeric(10,2);
  END IF;
END $$;

-- Add check constraint for payment_status (drop first for idempotency)
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'recharges_payment_status_check') THEN
    ALTER TABLE recharges ADD CONSTRAINT recharges_payment_status_check
    CHECK (payment_status = ANY (ARRAY['pending'::text, 'paid'::text, 'failed'::text, 'refunded'::text]));
  END IF;
END $$;
